#!/bin/bash
# MemWatch Clean Build Script - Removes build artifacts but preserves source

echo "🧹 MemWatch Build Cleanup"
echo "========================="

cd "$(dirname "$0")"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

deleted_count=0

# Function to safely delete build artifacts
delete_if_exists() {
    local path=$1
    local description=$2
    
    if [ -e "$path" ]; then
        echo -e "${YELLOW}Deleting: ${description}${NC}"
        rm -rf "$path" || true
        deleted_count=$((deleted_count + 1))
        echo -e "${GREEN}  ✓ Deleted${NC}"
    fi
}

echo -e "${YELLOW}Cleaning build artifacts...${NC}"

# Clean Node.js build
delete_if_exists "build" "Node.js build directory"

# Clean Python cache
delete_if_exists "__pycache__" "Python cache"
delete_if_exists "adapters/__pycache__" "Python cache (adapters)"
delete_if_exists "tests/__pycache__" "Python cache (tests)"

# Clean compiled Python files
find . -name "*.pyc" -delete 2>/dev/null || true
find . -name "*.pyo" -delete 2>/dev/null || true
echo -e "${GREEN}  ✓ Cleaned .pyc/.pyo files${NC}"
deleted_count=$((deleted_count + 1))

# Clean pytest cache
delete_if_exists ".pytest_cache" "pytest cache"

# Report
if [ "$deleted_count" -gt 0 ]; then
    echo -e "${GREEN}✅ Cleanup complete! ($deleted_count items deleted)${NC}"
else
    echo -e "${GREEN}✅ Nothing to clean${NC}"
fi

echo ""
echo "Preserved items:"
echo "  ✓ Source code (*.py, *.js, *.c, *.h)"
echo "  ✓ Tests (tests/)"
echo "  ✓ Configuration files (*.gyp, *.ini)"

# Report
if [ $deleted_count -gt 0 ]; then
    echo -e "${GREEN}✅ Cleanup complete! (${deleted_count} items deleted)${NC}"
else
    echo -e "${GREEN}✅ Nothing to clean${NC}"
fi

echo ""
echo "Preserved items:"
echo "  ✓ Source code (*.py, *.js, *.c, *.h)"
echo "  ✓ Tests (tests/)"
echo "  ✓ Configuration files (*.gyp, *.ini)"
