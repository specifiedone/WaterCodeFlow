#!/bin/bash
# Quick Test Runner for MemWatch
# Tests are fully interruptible with Ctrl+C

set -e

cd "$(dirname "$0")"

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║  MemWatch Test Suite - Running 65 Tests                       ║"
echo "║  All tests support Ctrl+C interruption (30s timeout)          ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

# Ensure pytest-timeout is installed
python3 -m pip install -q pytest pytest-timeout 2>/dev/null || true

# Run all tests
echo "Running 65 comprehensive tests..."
echo ""

python3 -m pytest tests/ -v --timeout=30

echo ""
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║  ✅ All 65 tests passed!                                      ║"
echo "║  Tests are interruptible — try Ctrl+C anytime                ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
