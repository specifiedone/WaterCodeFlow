"""MemWatch C++ Language Adapter"""
import subprocess, sys, os
_initialized = False
def initialize(config):
    global _initialized
    _initialized = True
    if config.get('debug'): print("[C++ Adapter] Initialized")
def run_script(script, args, config):
    if not _initialized: return 1
    if not os.path.exists(script):
        print(f"❌ Script not found: {script}", file=sys.stderr)
        return 1
    try:
        exe = script.replace('.cpp', '')
        cmd = ['g++', '-std=c++17', script, '-o', exe]
        subprocess.run(cmd, check=True)
        result = subprocess.run([exe] + args)
        return result.returncode
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        return 1
def shutdown():
    global _initialized
    _initialized = False
