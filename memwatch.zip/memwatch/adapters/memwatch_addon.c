/**
 * MemWatch Node.js Adapter
 * 
 * N-API bindings to libmemwatch.so for Node.js integration
 * Provides memory tracking and SQL event emission
 */

#include <node_api.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include "../core/memwatch_core.h"

/**
 * Helper macros for N-API
 */
#define DECLARE_NAPI_METHOD(name, func) \
  { name, 0, func, 0, 0, 0, napi_default, 0 }

#define NAPI_CALL(env, call) \
  do { \
    napi_status status = (call); \
    if (status != napi_ok) { \
      napi_throw_error(env, NULL, "N-API call failed"); \
    } \
  } while(0)

/**
 * mw_init wrapper
 */
static napi_value init(napi_env env, napi_callback_info info) {
    int ret = mw_init();
    
    napi_value result;
    NAPI_CALL(env, napi_create_int32(env, ret, &result));
    return result;
}

/**
 * mw_shutdown wrapper
 */
static napi_value shutdown(napi_env env, napi_callback_info info) {
    mw_shutdown();
    
    napi_value result;
    NAPI_CALL(env, napi_get_undefined(env, &result));
    return result;
}

/**
 * mw_set_tracking_enabled wrapper
 */
static napi_value set_tracking_enabled(napi_env env, napi_callback_info info) {
    size_t argc = 1;
    napi_value argv[1];
    NAPI_CALL(env, napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
    
    if (argc < 1) {
        napi_throw_error(env, NULL, "Expected 1 argument");
        return NULL;
    }
    
    int32_t enabled;
    NAPI_CALL(env, napi_get_value_int32(env, argv[0], &enabled));
    
    mw_set_tracking_enabled(enabled);
    
    napi_value result;
    NAPI_CALL(env, napi_get_undefined(env, &result));
    return result;
}

/**
 * mw_emit_sql_event wrapper
 */
static napi_value emit_sql_event(napi_env env, napi_callback_info info) {
    size_t argc = 1;
    napi_value argv[1];
    NAPI_CALL(env, napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
    
    if (argc < 1) {
        napi_throw_error(env, NULL, "Expected event object");
        return NULL;
    }
    
    napi_value event_obj = argv[0];
    
    // Create C event structure
    mw_event_sql_t event = {0};
    event.timestamp_ns = mw_get_time_ns();
    event.pid = getpid();
    event.thread_id = pthread_self();
    
    // Extract fields from event_obj
    napi_value field;
    size_t str_len;
    char buffer[1024];
    
    // db_type
    NAPI_CALL(env, napi_get_named_property(env, event_obj, "db_type", &field));
    NAPI_CALL(env, napi_get_value_string_utf8(env, field, buffer, sizeof(buffer), &str_len));
    event.db_type = strdup(buffer);
    
    // query
    NAPI_CALL(env, napi_get_named_property(env, event_obj, "query", &field));
    NAPI_CALL(env, napi_get_value_string_utf8(env, field, buffer, sizeof(buffer), &str_len));
    event.query = strdup(buffer);
    
    // params (optional)
    if (napi_get_named_property(env, event_obj, "params", &field) == napi_ok) {
        NAPI_CALL(env, napi_get_value_string_utf8(env, field, buffer, sizeof(buffer), &str_len));
        event.params = strdup(buffer);
    }
    
    // call_file
    NAPI_CALL(env, napi_get_named_property(env, event_obj, "call_file", &field));
    NAPI_CALL(env, napi_get_value_string_utf8(env, field, buffer, sizeof(buffer), &str_len));
    event.call_file = strdup(buffer);
    
    // call_line
    NAPI_CALL(env, napi_get_named_property(env, event_obj, "call_line", &field));
    NAPI_CALL(env, napi_get_value_uint32(env, field, &event.call_line));
    
    // execution_time_us
    NAPI_CALL(env, napi_get_named_property(env, event_obj, "execution_time_us", &field));
    NAPI_CALL(env, napi_get_value_int64(env, field, (int64_t*)&event.execution_time_us));
    
    event.language = "node";
    
    // Emit the event
    int ret = mw_emit_sql_event(&event);
    
    // Cleanup
    free((void*)event.db_type);
    free((void*)event.query);
    if (event.params) free((void*)event.params);
    free((void*)event.call_file);
    
    napi_value result;
    NAPI_CALL(env, napi_create_int32(env, ret, &result));
    return result;
}

/**
 * mw_get_time_ns wrapper
 */
static napi_value get_time_ns(napi_env env, napi_callback_info info) {
    uint64_t ts = mw_get_time_ns();
    
    napi_value result;
    NAPI_CALL(env, napi_create_bigint_uint64(env, ts, &result));
    return result;
}

/**
 * mw_get_event_count wrapper
 */
static napi_value get_event_count(napi_env env, napi_callback_info info) {
    uint64_t count = mw_get_event_count();
    
    napi_value result;
    NAPI_CALL(env, napi_create_bigint_uint64(env, count, &result));
    return result;
}

/**
 * mw_get_memory_used wrapper
 */
static napi_value get_memory_used(napi_env env, napi_callback_info info) {
    size_t used = mw_get_memory_used();
    
    napi_value result;
    NAPI_CALL(env, napi_create_uint32(env, (uint32_t)used, &result));
    return result;
}

/**
 * Module exports
 */
static napi_value init_module(napi_env env, napi_value exports) {
    napi_property_descriptor properties[] = {
        DECLARE_NAPI_METHOD("init", init),
        DECLARE_NAPI_METHOD("shutdown", shutdown),
        DECLARE_NAPI_METHOD("set_tracking_enabled", set_tracking_enabled),
        DECLARE_NAPI_METHOD("emit_sql_event", emit_sql_event),
        DECLARE_NAPI_METHOD("get_time_ns", get_time_ns),
        DECLARE_NAPI_METHOD("get_event_count", get_event_count),
        DECLARE_NAPI_METHOD("get_memory_used", get_memory_used),
    };
    
    NAPI_CALL(env, napi_define_properties(
        env, exports, sizeof(properties) / sizeof(properties[0]), properties));
    
    return exports;
}

NAPI_MODULE(memwatch_addon, init_module)
