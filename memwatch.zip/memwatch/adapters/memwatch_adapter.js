/**
 * MemWatch Node.js Adapter
 * 
 * Responsibilities:
 * - Load N-API native module
 * - Wrap local variable relocation
 * - Track SQL queries (sqlite3, better-sqlite3, mysql2)
 * - Manage frame lifecycle
 */

const addon = require('./memwatch_addon');
const path = require('path');
const fs = require('fs');

// ============================================================================
// ADAPTER STATE
// ============================================================================

const adapterState = {
    initialized: false,
    frameCounter: 0,
    trackedAllocations: new Map(),
    config: {},
};

// ============================================================================
// TIMING
// ============================================================================

function getCurrentTimeNs() {
    return addon.get_time_ns();
}

// ============================================================================
// LOCAL VARIABLE RELOCATION
// ============================================================================

class LocalVariable {
    constructor(name, value, functionName, file, line, frameId) {
        this.name = name;
        this.value = value;
        this.functionName = functionName;
        this.file = file;
        this.line = line;
        this.frameId = frameId;
    }
    
    get() {
        return this.value;
    }
    
    set(value) {
        this.value = value;
    }
}

class FrameScope {
    constructor(frameId, functionName, file, line) {
        this.frameId = frameId;
        this.functionName = functionName;
        this.file = file;
        this.line = line;
        this.locals = new Map();
    }
    
    allocateLocal(name, value) {
        const localVar = new LocalVariable(name, value, this.functionName, this.file, this.line, this.frameId);
        this.locals.set(name, localVar);
        return localVar;
    }
    
    freeAll() {
        this.locals.clear();
    }
}

// ============================================================================
// PUBLIC API
// ============================================================================

function initialize() {
    if (adapterState.initialized) {
        return;
    }
    
    const ret = addon.init();
    if (ret !== 0) {
        throw new Error('Failed to initialize MemWatch core');
    }
    
    adapterState.initialized = true;
}

function shutdown() {
    if (!adapterState.initialized) {
        return;
    }
    
    addon.shutdown();
    adapterState.initialized = false;
}

function setConfig(config) {
    adapterState.config = config;
}

function emitSqlEvent(dbType, query, params, callFile, callLine, executionTimeUs) {
    if (!adapterState.initialized) {
        return;
    }
    
    const event = {
        db_type: dbType,
        query: query,
        params: params ? JSON.stringify(params) : '',
        call_file: callFile || '',
        call_line: callLine || 0,
        execution_time_us: executionTimeUs || 0,
    };
    
    addon.emit_sql_event(event);
}

function trackFrame(functionName, file, line) {
    adapterState.frameCounter++;
    const frameId = adapterState.frameCounter;
    return new FrameScope(frameId, functionName, file, line);
}

// ============================================================================
// DATABASE WRAPPERS
// ============================================================================

function wrapSqlite3() {
    try {
        const sqlite3 = require('sqlite3').verbose();
        
        const originalRun = sqlite3.Database.prototype.run;
        sqlite3.Database.prototype.run = function(sql, ...args) {
            const callback = typeof args[args.length - 1] === 'function' ? args[args.length - 1] : null;
            const params = args.length > 1 ? args.slice(0, -1) : (args.length === 1 && callback ? [] : args);
            
            const stack = new Error().stack;
            const stackLines = stack.split('\n');
            const caller = stackLines[2] || '';
            const fileMatch = caller.match(/\((.+):(\d+):\d+\)/);
            const callFile = fileMatch ? fileMatch[1] : '';
            const callLine = fileMatch ? parseInt(fileMatch[2], 10) : 0;
            
            const startTime = process.hrtime();
            
            const wrappedCallback = (err, ...cbArgs) => {
                const elapsed = process.hrtime(startTime);
                const executionTimeUs = elapsed[0] * 1e6 + elapsed[1] / 1e3;
                
                const paramsObj = {};
                if (Array.isArray(params) && params.length > 0) {
                    paramsObj.params = params;
                }
                
                emitSqlEvent('sqlite', sql, paramsObj, callFile, callLine, executionTimeUs);
                
                if (callback) {
                    callback(err, ...cbArgs);
                }
            };
            
            return originalRun.call(this, sql, params, wrappedCallback);
        };
        
        const originalPrepare = sqlite3.Database.prototype.prepare;
        sqlite3.Database.prototype.prepare = function(sql) {
            const stmt = originalPrepare.call(this, sql);
            
            const originalStmtRun = stmt.run;
            stmt.run = function(...args) {
                const callback = typeof args[args.length - 1] === 'function' ? args[args.length - 1] : null;
                const params = args.length > 1 ? args.slice(0, -1) : (args.length === 1 && callback ? [] : args);
                
                const stack = new Error().stack;
                const stackLines = stack.split('\n');
                const caller = stackLines[2] || '';
                const fileMatch = caller.match(/\((.+):(\d+):\d+\)/);
                const callFile = fileMatch ? fileMatch[1] : '';
                const callLine = fileMatch ? parseInt(fileMatch[2], 10) : 0;
                
                const startTime = process.hrtime();
                
                const wrappedCallback = (err, ...cbArgs) => {
                    const elapsed = process.hrtime(startTime);
                    const executionTimeUs = elapsed[0] * 1e6 + elapsed[1] / 1e3;
                    
                    const paramsObj = {};
                    if (Array.isArray(params) && params.length > 0) {
                        paramsObj.params = params;
                    }
                    
                    emitSqlEvent('sqlite', sql, paramsObj, callFile, callLine, executionTimeUs);
                    
                    if (callback) {
                        callback(err, ...cbArgs);
                    }
                };
                
                if (callback) {
                    return originalStmtRun.call(this, ...params, wrappedCallback);
                } else {
                    return originalStmtRun.call(this, ...params);
                }
            };
            
            return stmt;
        };
    } catch (e) {
        // sqlite3 not available
    }
}

function wrapMysql2() {
    try {
        const mysql2 = require('mysql2');
        
        const originalQuery = mysql2.Connection.prototype.query;
        mysql2.Connection.prototype.query = function(sql, values, cb) {
            const stack = new Error().stack;
            const stackLines = stack.split('\n');
            const caller = stackLines[2] || '';
            const fileMatch = caller.match(/\((.+):(\d+):\d+\)/);
            const callFile = fileMatch ? fileMatch[1] : '';
            const callLine = fileMatch ? parseInt(fileMatch[2], 10) : 0;
            
            const startTime = process.hrtime();
            
            const wrappedCallback = (err, ...cbArgs) => {
                const elapsed = process.hrtime(startTime);
                const executionTimeUs = elapsed[0] * 1e6 + elapsed[1] / 1e3;
                
                const paramsObj = {};
                if (Array.isArray(values) && values.length > 0) {
                    paramsObj.values = values;
                } else if (typeof values === 'object' && values !== null) {
                    paramsObj.values = values;
                }
                
                emitSqlEvent('mysql', sql, paramsObj, callFile, callLine, executionTimeUs);
                
                if (cb) {
                    cb(err, ...cbArgs);
                }
            };
            
            if (typeof values === 'function') {
                return originalQuery.call(this, sql, wrappedCallback);
            } else {
                return originalQuery.call(this, sql, values, wrappedCallback);
            }
        };
    } catch (e) {
        // mysql2 not available
    }
}

// ============================================================================
// EXPORTS
// ============================================================================

module.exports = {
    initialize,
    shutdown,
    setConfig,
    emitSqlEvent,
    trackFrame,
    LocalVariable,
    FrameScope,
    wrapSqlite3,
    wrapMysql2,
};
