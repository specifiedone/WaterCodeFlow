#!/usr/bin/env node

/**
 * MemWatch Node.js/JavaScript Runtime with SQL Tracking
 * 
 * Supports:
 * - Memory tracking via process.memoryUsage()
 * - SQL query tracking (sqlite3, better-sqlite3, mysql2, pg, sequelize)
 * - Variable tracking
 * - File/module scoping
 */

const fs = require('fs');
const path = require('path');
const Module = require('module');

class MemWatch {
    constructor(config) {
        this.config = config;
        this.snapshots = [];
        this.sqlEvents = [];
        this.startTime = Date.now();
        this.initialMem = process.memoryUsage();
        this.debug = (config.debug == 1) || config.debug || false;
        this.trackFile = config.track_file;
        this.trackModule = config.track_module;
        this.memwatchEnabled = (config.track_memory == 1) || false;
        this.sqlEnabled = (config.track_sql == 1) || false;
        
        if (this.debug) {
            console.error('[MemWatch] Initialized');
            console.error(`  Memory tracking: ${this.memwatchEnabled}`);
            console.error(`  SQL tracking: ${this.sqlEnabled}`);
        }
    }

    trackSqlQuery(query, params, source) {
        if (!this.sqlEnabled) return;

        this.sqlEvents.push({
            timestamp: Date.now() - this.startTime,
            query: String(query).substring(0, 200),
            source: source
        });

        if (this.debug && this.sqlEvents.length <= 5) {
            console.error(`[MemWatch-SQL] ${source}: ${String(query).substring(0, 60)}`);
        }
    }

    takeSnapshot() {
        if (!this.memwatchEnabled) return;
        const mem = process.memoryUsage();
        this.snapshots.push({
            timestamp: Date.now() - this.startTime,
            heapUsed: mem.heapUsed
        });
    }

    setupSQLTracking() {
        if (!this.sqlEnabled) return;

        const self = this;

        // Wrap sqlite3
        try {
            const sqlite3 = require('sqlite3');
            const origRun = sqlite3.Database.prototype.run;
            if (origRun) {
                sqlite3.Database.prototype.run = function(sql, ...args) {
                    self.trackSqlQuery(sql, [], 'sqlite3.run');
                    return origRun.apply(this, [sql, ...args]);
                };
            }
            if (this.debug) console.error('[MemWatch] Instrumented sqlite3');
        } catch (e) {}

        // Wrap better-sqlite3
        try {
            const Database = require('better-sqlite3');
            const origPrepare = Database.prototype.prepare;
            if (origPrepare) {
                Database.prototype.prepare = function(sql) {
                    self.trackSqlQuery(sql, [], 'better-sqlite3.prepare');
                    return origPrepare.call(this, sql);
                };
            }
            if (this.debug) console.error('[MemWatch] Instrumented better-sqlite3');
        } catch (e) {}

        // Wrap mysql2
        try {
            const mysql2 = require('mysql2');
            const origCreateConnection = mysql2.createConnection;
            if (origCreateConnection) {
                mysql2.createConnection = function(config) {
                    const conn = origCreateConnection.apply(this, arguments);
                    const origQuery = conn.query;
                    if (origQuery) {
                        conn.query = function(sql, ...args) {
                            self.trackSqlQuery(sql, [], 'mysql2.query');
                            return origQuery.apply(this, [sql, ...args]);
                        };
                    }
                    return conn;
                };
            }
            if (this.debug) console.error('[MemWatch] Instrumented mysql2');
        } catch (e) {}

        // Wrap pg
        try {
            const pg = require('pg');
            const origQuery = pg.Client.prototype.query;
            if (origQuery) {
                pg.Client.prototype.query = function(sql, ...args) {
                    self.trackSqlQuery(sql, [], 'pg.query');
                    return origQuery.apply(this, [sql, ...args]);
                };
            }
            if (this.debug) console.error('[MemWatch] Instrumented pg');
        } catch (e) {}
    }

    async executeScript(scriptPath, args) {
        try {
            if (!fs.existsSync(scriptPath)) {
                console.error(`❌ Script not found: ${scriptPath}`);
                return 1;
            }

            // Setup SQL tracking BEFORE loading script
            this.setupSQLTracking();
            this.takeSnapshot();

            const scriptDir = path.dirname(path.resolve(scriptPath));
            const originalCwd = process.cwd();

            process.chdir(scriptDir);

            try {
                if (scriptPath.endsWith('.js')) {
                    process.argv[1] = scriptPath;
                    process.argv.splice(2, 0, ...args);
                    delete require.cache[path.resolve(scriptPath)];
                    require(path.resolve(scriptPath));
                }
            } catch (err) {
                console.error(`❌ Error: ${err.message}`);
                if (this.debug) console.error(err.stack);
                return 1;
            } finally {
                process.chdir(originalCwd);
            }

            this.takeSnapshot();
            this.printResults();

            return 0;
        } catch (err) {
            console.error(`❌ Fatal error: ${err.message}`);
            return 1;
        }
    }

    printResults() {
        if (this.debug) {
            if (this.memwatchEnabled && this.snapshots.length > 0) {
                const initial = this.snapshots[0].heapUsed;
                const final = this.snapshots[this.snapshots.length - 1].heapUsed;
                const growth = (final - initial) / 1024 / 1024;
                console.error(`[MemWatch] Memory: ${growth.toFixed(2)}MB growth`);
                console.error(`[MemWatch] Snapshots: ${this.snapshots.length}`);
            }

            if (this.sqlEnabled && this.sqlEvents.length > 0) {
                console.error(`[MemWatch] SQL queries tracked: ${this.sqlEvents.length}`);
                this.sqlEvents.slice(0, 5).forEach((e, i) => {
                    console.error(`  [${i + 1}] ${e.source}: ${e.query.substring(0, 50)}`);
                });
                if (this.sqlEvents.length > 5) {
                    console.error(`  ... and ${this.sqlEvents.length - 5} more`);
                }
            }
        }
    }
}

// Main execution
async function main() {
    const args = process.argv.slice(2);

    if (args.length < 2) {
        console.error('Usage: node memwatch.js <config.json> <script.js> [args...]');
        process.exit(1);
    }

    const configPath = args[0];
    const scriptPath = args[1];
    const scriptArgs = args.slice(2);

    let config;
    try {
        const configData = fs.readFileSync(configPath, 'utf8');
        config = JSON.parse(configData);
    } catch (err) {
        console.error(`❌ Failed to load config: ${err.message}`);
        process.exit(1);
    }

    const mw = new MemWatch(config);
    const exitCode = await mw.executeScript(scriptPath, scriptArgs);
    process.exit(exitCode);
}

if (require.main === module) {
    main().catch(err => {
        console.error(`Fatal: ${err.message}`);
        process.exit(1);
    });
}

module.exports = { MemWatch };
