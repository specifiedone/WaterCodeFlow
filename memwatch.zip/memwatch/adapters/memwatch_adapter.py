"""
MemWatch Python Adapter

Responsibilities:
- Load and interface with C core library (libmemwatch.so)
- Relocate local variables from stack to core-managed pages
- Generate frame IDs for function invocations
- Manage variable lifetimes
- Wrap SQL drivers (sqlite3, mysql.connector, pymysql)
- Emit events to core
"""

import ctypes
import sys
import os
import json
import threading
import inspect
from typing import Any, Dict, List, Optional, Callable
from contextlib import contextmanager
from functools import wraps
import weakref

# ============================================================================
# CTYPES BINDINGS TO C CORE
# ============================================================================

# Determine library path
MEMWATCH_LIB_PATH = os.path.join(
    os.path.dirname(__file__), '..', 'core', 'libmemwatch.so'
)
MEMWATCH_LIB_PATH = os.path.abspath(MEMWATCH_LIB_PATH)

if not os.path.exists(MEMWATCH_LIB_PATH):
    # Try alternate path
    MEMWATCH_LIB_PATH = os.path.join(os.getcwd(), 'memwatch', 'core', 'libmemwatch.so')
    if not os.path.exists(MEMWATCH_LIB_PATH):
        MEMWATCH_LIB_PATH = os.path.join(os.getcwd(), 'core', 'libmemwatch.so')

_libmw = ctypes.CDLL(MEMWATCH_LIB_PATH)

# ============================================================================
# C TYPE DEFINITIONS
# ============================================================================

class mw_var_meta_t(ctypes.Structure):
    pass

mw_var_meta_t._fields_ = [
    ('scope', ctypes.c_int),              # MW_SCOPE_GLOBAL=1, MW_SCOPE_LOCAL=2
    ('thread_id', ctypes.c_uint64),
    ('frame_id', ctypes.c_uint64),
    ('var_id', ctypes.c_uint64),
    ('var_name', ctypes.c_char_p),
    ('function_name', ctypes.c_char_p),
    ('file', ctypes.c_char_p),
    ('line', ctypes.c_uint32),
    ('user_data', ctypes.c_void_p),
]

class mw_event_sql_t(ctypes.Structure):
    _fields_ = [
        ('timestamp_ns', ctypes.c_uint64),
        ('pid', ctypes.c_uint32),
        ('thread_id', ctypes.c_uint64),
        ('db_type', ctypes.c_char_p),
        ('query', ctypes.c_char_p),
        ('params', ctypes.c_char_p),
        ('execution_time_us', ctypes.c_uint64),
        ('call_file', ctypes.c_char_p),
        ('call_line', ctypes.c_uint32),
        ('language', ctypes.c_char_p),
    ]

class mw_config_t(ctypes.Structure):
    _fields_ = [
        ('track_memory', ctypes.c_int),
        ('track_locals', ctypes.c_int),
        ('track_globals', ctypes.c_int),
        ('track_threads', ctypes.c_int),
        ('track_sql', ctypes.c_int),
        ('debug', ctypes.c_int),
        ('store_bytes', ctypes.c_int),
        ('output_file', ctypes.c_char_p),
        ('filter_vars', ctypes.POINTER(ctypes.c_char_p)),
        ('filter_var_count', ctypes.c_int),
    ]

# ============================================================================
# WRAPPER FUNCTIONS
# ============================================================================

def _bind_func(name, argtypes, restype):
    """Helper to bind C functions"""
    func = getattr(_libmw, name)
    func.argtypes = argtypes
    func.restype = restype
    return func

mw_init = _bind_func('mw_init', [], ctypes.c_int)
mw_shutdown = _bind_func('mw_shutdown', [], None)
mw_set_tracking_enabled = _bind_func('mw_set_tracking_enabled', [ctypes.c_int], None)
mw_alloc_tracked = _bind_func('mw_alloc_tracked', [ctypes.c_size_t, ctypes.POINTER(mw_var_meta_t)], ctypes.c_void_p)
mw_free_tracked = _bind_func('mw_free_tracked', [ctypes.c_void_p], ctypes.c_int)
mw_get_meta = _bind_func('mw_get_meta', [ctypes.c_void_p], ctypes.POINTER(mw_var_meta_t))
mw_set_config = _bind_func('mw_set_config', [ctypes.POINTER(mw_config_t)], ctypes.c_int)
mw_emit_sql_event = _bind_func('mw_emit_sql_event', [ctypes.POINTER(mw_event_sql_t)], ctypes.c_int)
mw_get_time_ns = _bind_func('mw_get_time_ns', [], ctypes.c_uint64)
mw_get_event_count = _bind_func('mw_get_event_count', [], ctypes.c_uint64)
mw_get_memory_used = _bind_func('mw_get_memory_used', [], ctypes.c_size_t)

# ============================================================================
# ADAPTER STATE
# ============================================================================

_adapter_state = {
    'initialized': False,
    'callback': None,
    'events': [],
    'lock': threading.RLock(),
    'frame_counter': 0,
    'tracked_allocations': weakref.WeakKeyDictionary(),
}

# ============================================================================
# LOCAL VARIABLE RELOCATION
# ============================================================================

class LocalVariable:
    """Represents a relocated local variable on a core-managed page"""
    
    def __init__(self, name: str, value: Any, function: str, file: str, line: int, frame_id: int):
        self.name = name
        self.function = function
        self.file = file
        self.line = line
        self.frame_id = frame_id
        self._value = value
        self._ptr = None
        self._size = 0
        
    def _allocate_on_core_page(self):
        """Allocate memory on a core-managed page"""
        # Serialize value
        value_bytes = pickle.dumps(self._value)
        self._size = len(value_bytes)
        
        # Create metadata
        meta = mw_var_meta_t()
        meta.scope = 2  # MW_SCOPE_LOCAL
        meta.thread_id = threading.get_ident()
        meta.frame_id = self.frame_id
        meta.var_id = id(self)
        meta.var_name = self.name.encode('utf-8')
        meta.function_name = self.function.encode('utf-8')
        meta.file = self.file.encode('utf-8')
        meta.line = self.line
        meta.user_data = id(self)
        
        # Allocate on core page
        self._ptr = mw_alloc_tracked(self._size, meta)
        if not self._ptr:
            raise RuntimeError(f"Failed to allocate tracked memory for {self.name}")
        
        # Copy value to core page
        ctypes.memmove(self._ptr, ctypes.c_char_p(value_bytes), self._size)
        
        _adapter_state['tracked_allocations'][self] = self._ptr
    
    def get(self) -> Any:
        """Get current value from core page"""
        if not self._ptr:
            return self._value
        
        # Read from core page
        import pickle
        value_bytes = ctypes.string_at(self._ptr, self._size)
        return pickle.loads(value_bytes)
    
    def set(self, value: Any):
        """Set value on core page"""
        self._value = value
        if not self._ptr:
            self._allocate_on_core_page()
        
        # Serialize and write to core page
        import pickle
        value_bytes = pickle.dumps(value)
        if len(value_bytes) > self._size:
            # Need to reallocate
            mw_free_tracked(self._ptr)
            self._size = len(value_bytes)
            self._allocate_on_core_page()
        else:
            # Update existing
            ctypes.memmove(self._ptr, ctypes.c_char_p(value_bytes), len(value_bytes))
    
    def free(self):
        """Free the core page allocation"""
        if self._ptr:
            mw_free_tracked(self._ptr)
            self._ptr = None

import pickle


class FrameScope:
    """Represents a function frame with its local variables"""
    
    def __init__(self, frame_id: int, function: str, file: str, line: int):
        self.frame_id = frame_id
        self.function = function
        self.file = file
        self.line = line
        self.locals: Dict[str, LocalVariable] = {}
    
    def allocate_local(self, name: str, value: Any) -> LocalVariable:
        """Allocate a tracked local variable"""
        local_var = LocalVariable(name, value, self.function, self.file, self.line, self.frame_id)
        local_var._allocate_on_core_page()
        self.locals[name] = local_var
        return local_var
    
    def free_all(self):
        """Free all locals in this frame"""
        for local_var in self.locals.values():
            local_var.free()
        self.locals.clear()


# ============================================================================
# PUBLIC API
# ============================================================================

def initialize():
    """Initialize MemWatch adapter"""
    with _adapter_state['lock']:
        if _adapter_state['initialized']:
            return
        
        if mw_init() != 0:
            raise RuntimeError("Failed to initialize MemWatch core")
        
        _adapter_state['initialized'] = True


def shutdown():
    """Shutdown MemWatch adapter"""
    with _adapter_state['lock']:
        if not _adapter_state['initialized']:
            return
        
        mw_shutdown()
        _adapter_state['initialized'] = False


def set_config(config: Dict):
    """Set MemWatch configuration"""
    cfg = mw_config_t()
    cfg.track_memory = config.get('track_memory', 1)
    cfg.track_locals = config.get('track_locals', 0)
    cfg.track_globals = config.get('track_globals', 0)
    cfg.track_threads = config.get('track_threads', 1)
    cfg.track_sql = config.get('track_sql', 0)
    cfg.debug = config.get('debug', 0)
    cfg.store_bytes = config.get('store_bytes', -1)
    
    output_file = config.get('output_file', None)
    if output_file:
        cfg.output_file = output_file.encode('utf-8')
    
    mw_set_config(ctypes.byref(cfg))


def emit_sql_event(db_type: str, query: str, params: Optional[Dict] = None,
                   call_file: str = '', call_line: int = 0, execution_time_us: int = 0):
    """Emit a SQL query event"""
    if not _adapter_state['initialized']:
        return
    
    event = mw_event_sql_t()
    event.timestamp_ns = mw_get_time_ns()
    event.pid = os.getpid()
    event.thread_id = threading.get_ident()
    event.db_type = db_type.encode('utf-8')
    event.query = query.encode('utf-8')
    
    if params:
        event.params = json.dumps(params).encode('utf-8')
    
    event.call_file = call_file.encode('utf-8') if call_file else b''
    event.call_line = call_line
    event.execution_time_us = execution_time_us
    event.language = b'python'
    
    mw_emit_sql_event(ctypes.byref(event))


@contextmanager
def track_frame(function_name: str, file: str = '', line: int = 0):
    """Context manager for tracking a function frame"""
    with _adapter_state['lock']:
        _adapter_state['frame_counter'] += 1
        frame_id = _adapter_state['frame_counter']
    
    frame = FrameScope(frame_id, function_name, file, line)
    
    try:
        yield frame
    finally:
        frame.free_all()


# ============================================================================
# DATABASE WRAPPERS
# ============================================================================

def wrap_sqlite3():
    """Wrap sqlite3 to track queries"""
    try:
        import sqlite3
    except ImportError:
        return
    
    original_connect = sqlite3.connect
    
    class TrackedCursor:
        """Wrapper around sqlite3.Cursor to track queries"""
        def __init__(self, cursor):
            self._cursor = cursor
        
        def execute(self, sql, parameters=(), **kwargs):
            frame = inspect.currentframe()
            call_file = frame.f_back.f_code.co_filename if frame.f_back else ''
            call_line = frame.f_back.f_lineno if frame.f_back else 0
            
            import time
            start = time.perf_counter()
            
            try:
                result = self._cursor.execute(sql, parameters, **kwargs)
            finally:
                elapsed = int((time.perf_counter() - start) * 1e6)
                
                params_dict = {}
                if isinstance(parameters, dict):
                    params_dict = parameters
                elif isinstance(parameters, (list, tuple)) and parameters:
                    params_dict = {'args': parameters}
                
                emit_sql_event('sqlite', sql, params_dict, call_file, call_line, elapsed)
            
            return result
        
        def executemany(self, sql, seq_of_parameters, **kwargs):
            frame = inspect.currentframe()
            call_file = frame.f_back.f_code.co_filename if frame.f_back else ''
            call_line = frame.f_back.f_lineno if frame.f_back else 0
            
            import time
            start = time.perf_counter()
            
            try:
                result = self._cursor.executemany(sql, seq_of_parameters, **kwargs)
            finally:
                elapsed = int((time.perf_counter() - start) * 1e6)
                emit_sql_event('sqlite', sql, {'batch_count': len(seq_of_parameters)}, call_file, call_line, elapsed)
            
            return result
        
        def fetchone(self):
            return self._cursor.fetchone()
        
        def fetchall(self):
            return self._cursor.fetchall()
        
        def fetchmany(self, size=-1):
            return self._cursor.fetchmany(size)
        
        def __getattr__(self, name):
            return getattr(self._cursor, name)
    
    class TrackedConnection:
        """Wrapper around sqlite3.Connection to track queries"""
        def __init__(self, conn):
            self._conn = conn
        
        def cursor(self):
            return TrackedCursor(self._conn.cursor())
        
        def __getattr__(self, name):
            return getattr(self._conn, name)
    
    @wraps(original_connect)
    def tracked_connect(database, *args, **kwargs):
        conn = original_connect(database, *args, **kwargs)
        return TrackedConnection(conn)
    
    sqlite3.connect = tracked_connect



def wrap_mysql():
    """Wrap mysql.connector and pymysql to track queries"""
    try:
        import mysql.connector
    except ImportError:
        pass
    else:
        original_execute = mysql.connector.MySQLCursor.execute
        
        @wraps(original_execute)
        def tracked_execute(self, operation, params=None, multi=False, **kwargs):
            frame = inspect.currentframe()
            call_file = frame.f_back.f_code.co_filename if frame.f_back else ''
            call_line = frame.f_back.f_lineno if frame.f_back else 0
            
            import time
            start = time.perf_counter()
            
            try:
                result = original_execute(self, operation, params, multi, **kwargs)
            finally:
                elapsed = int((time.perf_counter() - start) * 1e6)
                params_dict = {'params': params} if params else {}
                emit_sql_event('mysql', operation, params_dict, call_file, call_line, elapsed)
            
            return result
        
        mysql.connector.MySQLCursor.execute = tracked_execute
    
    try:
        import pymysql
    except ImportError:
        pass
    else:
        original_execute = pymysql.cursors.Cursor.execute
        
        @wraps(original_execute)
        def tracked_execute(self, query, args=None, **kwargs):
            frame = inspect.currentframe()
            call_file = frame.f_back.f_code.co_filename if frame.f_back else ''
            call_line = frame.f_back.f_lineno if frame.f_back else 0
            
            import time
            start = time.perf_counter()
            
            try:
                result = original_execute(self, query, args, **kwargs)
            finally:
                elapsed = int((time.perf_counter() - start) * 1e6)
                params_dict = {'args': args} if args else {}
                emit_sql_event('mysql', query, params_dict, call_file, call_line, elapsed)
            
            return result
        
        pymysql.cursors.Cursor.execute = tracked_execute


# ============================================================================
# INITIALIZATION
# ============================================================================

__all__ = [
    'initialize',
    'shutdown',
    'set_config',
    'emit_sql_event',
    'track_frame',
    'LocalVariable',
    'FrameScope',
    'wrap_sqlite3',
    'wrap_mysql',
]
