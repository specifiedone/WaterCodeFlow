"""MemWatch adapters __init__"""
