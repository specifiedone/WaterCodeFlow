"""
MemWatch Node.js/JavaScript Language Adapter

Routes to the real Node.js memory tracking runtime (memwatch.js)
Implements the language adapter interface:
- initialize(config)
- run_script(script, args, config)
- shutdown()
"""

import subprocess
import sys
import json
import os
import tempfile

_config = {}
_initialized = False

# Get the directory where this adapter file lives
_adapter_dir = os.path.dirname(os.path.abspath(__file__))
_memwatch_js = os.path.join(_adapter_dir, 'memwatch.js')


def initialize(config):
    """Initialize MemWatch for Node.js"""
    global _config, _initialized
    
    _config = config
    _initialized = True
    
    if config.get('debug'):
        print(f"[Node.js Adapter] Initialized")
        print(f"[Node.js Adapter] Track files: {config.get('track_file')}")
        print(f"[Node.js Adapter] Track modules: {config.get('track_module')}")
        print(f"[Node.js Adapter] Using runtime: {_memwatch_js}")


def run_script(script, args, config):
    """Execute a Node.js script with MemWatch tracking via memwatch.js runtime"""
    global _config
    
    if not _initialized:
        print("❌ Adapter not initialized", file=sys.stderr)
        return 1
    
    # Verify script exists
    if not os.path.exists(script):
        print(f"❌ Script not found: {script}", file=sys.stderr)
        return 1
    
    # Verify memwatch.js exists
    if not os.path.exists(_memwatch_js):
        print(f"❌ MemWatch runtime not found: {_memwatch_js}", file=sys.stderr)
        return 1
    
    if config.get('debug'):
        print(f"[Node.js Adapter] Running script: {script}")
        print(f"[Node.js Adapter] Args: {args}")
    
    try:
        # Create temporary config file for Node.js runtime
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(config, f)
            config_file = f.name
        
        try:
            # Execute via Node.js memwatch runtime
            cmd = ['node', _memwatch_js, config_file, script] + (args if args else [])
            result = subprocess.run(cmd, cwd=os.path.dirname(os.path.abspath(script)))
            return result.returncode
        
        finally:
            # Clean up config file
            try:
                os.unlink(config_file)
            except:
                pass
    
    except FileNotFoundError:
        print("❌ Node.js not found. Install with: apt-get install nodejs", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n[Node.js Adapter] Interrupted", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"❌ Error running script: {e}", file=sys.stderr)
        return 1


def shutdown():
    """Cleanup MemWatch"""
    global _initialized
    
    if _initialized:
        _initialized = False
        
        if _config.get('debug'):
            print(f"[Node.js Adapter] Shutdown complete")
