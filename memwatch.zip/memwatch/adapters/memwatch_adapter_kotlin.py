"""MemWatch Kotlin Language Adapter"""
import subprocess, sys, os
_initialized = False
def initialize(config):
    global _initialized
    _initialized = True
    if config.get('debug'): print("[Kotlin Adapter] Initialized")
def run_script(script, args, config):
    if not _initialized: return 1
    if not os.path.exists(script):
        print(f"❌ Script not found: {script}", file=sys.stderr)
        return 1
    try:
        cmd = ['kotlinc', '-script', script] + args
        result = subprocess.run(cmd)
        return result.returncode
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        return 1
def shutdown():
    global _initialized
    _initialized = False
