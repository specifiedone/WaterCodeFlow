"""
MemWatch Python Language Adapter

Implements the language adapter interface for Python:
- initialize(config)
- run_script(script, args, config)
- shutdown()
"""

import sys
import os
import json
import threading
from pathlib import Path

# Import the C core bindings
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from adapters import memwatch_adapter as mw


# Global state
_config = {}
_initialized = False


def initialize(config):
    """Initialize MemWatch for Python"""
    global _config, _initialized
    
    _config = config
    
    # Initialize C core
    mw.initialize()
    
    # Apply configuration to core
    mw.set_config({
        'track_memory': config.get('track_memory', 0),
        'track_locals': config.get('track_locals', 0),
        'track_globals': config.get('track_globals', 0),
        'track_threads': config.get('track_threads', 0),
        'track_sql': config.get('track_sql', 0),
        'debug': config.get('debug', 0),
        'store_bytes': config.get('store_bytes', -1),
        'output_file': config.get('output_file'),
    })
    
    # Enable SQL tracking if requested
    if config.get('track_sql'):
        mw.wrap_sqlite3()
        # MySQL adapters could be added here
    
    _initialized = True
    
    if config.get('debug'):
        print(f"[Python Adapter] Initialized")
        print(f"[Python Adapter] Track files: {config.get('track_file')}")
        print(f"[Python Adapter] Track modules: {config.get('track_module')}")


def run_script(script, args, config):
    """Execute a Python script with MemWatch tracking"""
    global _config
    
    if not _initialized:
        print("❌ Adapter not initialized", file=sys.stderr)
        return 1
    
    # Verify script exists
    if not os.path.exists(script):
        print(f"❌ Script not found: {script}", file=sys.stderr)
        return 1
    
    if config.get('debug'):
        print(f"[Python Adapter] Running script: {script}")
        print(f"[Python Adapter] Args: {args}")
    
    # Setup script environment
    script_dir = os.path.dirname(os.path.abspath(script))
    script_name = os.path.basename(script)
    
    # Create execution globals
    exec_globals = {
        '__name__': '__main__',
        '__file__': script,
        '__doc__': None,
        '__package__': None,
        '__loader__': None,
        '__spec__': None,
        '__cached__': None,
        '__builtins__': __builtins__,
        '__annotations__': {},
    }
    
    # Add sys.argv for the script
    old_argv = sys.argv
    sys.argv = [script] + args
    
    # Add script directory to path
    old_path = sys.path[:]
    sys.path.insert(0, script_dir)
    
    try:
        # Read and execute the script
        with open(script, 'r') as f:
            script_code = f.read()
        
        # Execute
        exec(compile(script_code, script, 'exec'), exec_globals)
        
        return 0
    
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
    except KeyboardInterrupt:
        print("\n[Python Adapter] Interrupted", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"❌ Script error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1
    
    finally:
        # Restore environment
        sys.argv = old_argv
        sys.path = old_path


def shutdown():
    """Cleanup MemWatch"""
    global _initialized
    
    if _initialized:
        mw.shutdown()
        _initialized = False
        
        if _config.get('debug'):
            print(f"[Python Adapter] Shutdown complete")
