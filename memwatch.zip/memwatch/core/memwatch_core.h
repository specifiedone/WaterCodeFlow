#ifndef MEMWATCH_CORE_H
#define MEMWATCH_CORE_H

#include <stdint.h>
#include <time.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * MemWatch Core API - Language-agnostic memory and SQL tracking
 * 
 * Core responsibilities:
 * - Own and protect memory pages
 * - Track writes via mprotect + signal handlers
 * - Store event metadata
 * - Enforce per-thread ownership
 * - Emit events to callbacks
 * 
 * Adapter responsibilities:
 * - Relocate locals (never stack pointers)
 * - Generate frame IDs
 * - Capture SQL context
 * - Manage language-specific lifetimes
 */

/* ============================================================================
   EVENT STRUCTURES
   ============================================================================ */

typedef enum {
    MW_EVENT_MEMORY_WRITE = 1,
    MW_EVENT_SQL_QUERY = 2,
} mw_event_type_t;

typedef enum {
    MW_SCOPE_GLOBAL = 1,
    MW_SCOPE_LOCAL = 2,
} mw_scope_t;

/**
 * Variable metadata - provided by adapter
 * Core stores this as-is, no interpretation
 */
typedef struct {
    mw_scope_t scope;           /* GLOBAL or LOCAL */
    uint64_t thread_id;         /* Thread that owns this allocation */
    uint64_t frame_id;          /* Logical frame ID (adapter-generated) */
    uint64_t var_id;            /* Stable variable identifier */
    const char* var_name;       /* Variable name (e.g., "x", "user") */
    const char* function_name;  /* Function context */
    const char* file;           /* Source file */
    uint32_t line;              /* Source line */
    void* user_data;            /* Opaque pointer for adapter use */
} mw_var_meta_t;

/**
 * Memory write event
 */
typedef struct {
    uint64_t timestamp_ns;      /* Nanosecond timestamp */
    uint32_t pid;               /* Process ID */
    uint64_t thread_id;         /* Thread ID */
    void* address;              /* Memory address written */
    size_t size;                /* Bytes written */
    uint8_t* old_value;         /* Full old value (must be size bytes) */
    uint8_t* new_value;         /* Full new value (must be size bytes) */
    mw_var_meta_t var_meta;     /* Variable metadata */
    const char* language;       /* "python" or "node" */
} mw_event_memory_t;

/**
 * SQL query event
 */
typedef struct {
    uint64_t timestamp_ns;      /* Nanosecond timestamp */
    uint32_t pid;               /* Process ID */
    uint64_t thread_id;         /* Thread ID */
    const char* db_type;        /* "sqlite" or "mysql" */
    const char* query;          /* Full query string */
    const char* params;         /* JSON-encoded parameters (may be NULL) */
    uint64_t execution_time_us; /* Execution time in microseconds */
    const char* call_file;      /* Source file of query call */
    uint32_t call_line;         /* Source line of query call */
    const char* language;       /* "python" or "node" */
} mw_event_sql_t;

/**
 * Unified event (tagged union)
 */
typedef struct {
    mw_event_type_t type;
    union {
        mw_event_memory_t memory;
        mw_event_sql_t sql;
    } data;
} mw_event_t;

/* ============================================================================
   CORE API
   ============================================================================ */

/**
 * Initialize MemWatch core
 * Call once at process start
 */
int mw_init(void);

/**
 * Shut down MemWatch core
 * Cleans up all protected pages, stops signal handlers
 */
void mw_shutdown(void);

/**
 * Enable/disable tracking globally
 */
void mw_set_tracking_enabled(int enabled);

/**
 * Register a callback for events
 * Callback is called with the event, and must NOT re-enter tracking
 * Tracking is temporarily disabled during callback execution
 */
typedef void (*mw_event_callback_t)(const mw_event_t* event);
int mw_register_callback(mw_event_callback_t callback);

/* ============================================================================
   MEMORY TRACKING API (Adapter Interface)
   ============================================================================ */

/**
 * Allocate a tracked memory region
 * 
 * This allocates page-aligned memory that is protected by mprotect.
 * Adapter must provide var_meta with:
 * - scope (LOCAL or GLOBAL)
 * - thread_id (MUST match actual thread)
 * - frame_id (for locals)
 * - var_id, var_name, file, line
 * 
 * Returns: pointer to allocated memory, or NULL on error
 */
void* mw_alloc_tracked(size_t size, const mw_var_meta_t* meta);

/**
 * Free a tracked memory region
 * Removes page protection, deregisters metadata
 */
int mw_free_tracked(void* ptr);

/**
 * Reallocate tracked memory
 * Preserves metadata, updates protection
 */
void* mw_realloc_tracked(void* ptr, size_t new_size);

/**
 * Get metadata for an allocation
 * Returns NULL if address is not tracked
 */
const mw_var_meta_t* mw_get_meta(void* ptr);

/**
 * Look up variable info by address
 * Used by signal handler to identify variable on write
 */
const mw_var_meta_t* mw_lookup_var_by_address(void* address);

/**
 * Register per-thread local page
 * Core creates one page per thread for local variables
 * Adapter calls this on thread startup
 */
int mw_register_thread_local_page(uint64_t thread_id);

/**
 * Unregister per-thread local page
 * Adapter calls this on thread exit
 */
int mw_unregister_thread_local_page(uint64_t thread_id);

/* ============================================================================
   SQL TRACKING API (Adapter Interface)
   ============================================================================ */

/**
 * Emit a SQL query event
 * Called by SQL adapters (sqlite, mysql) via wrapper code
 */
int mw_emit_sql_event(const mw_event_sql_t* event);

/* ============================================================================
   CONFIGURATION (CLI Interface)
   ============================================================================ */

typedef struct {
    int track_memory;           /* Enable memory tracking */
    int track_locals;           /* Track local variables */
    int track_globals;          /* Track global variables */
    int track_threads;          /* Include thread info */
    int track_sql;              /* Track SQL queries */
    int debug;                  /* Debug output */
    int store_bytes;            /* Max bytes to store (-1 = unlimited) */
    const char* output_file;    /* Output file path (optional) */
    const char** filter_vars;   /* Filtered variable names */
    int filter_var_count;       /* Number of filter_vars */
} mw_config_t;

/**
 * Set global configuration
 */
int mw_set_config(const mw_config_t* cfg);

/**
 * Get current configuration
 */
const mw_config_t* mw_get_config(void);

/* ============================================================================
   TIMING & STATISTICS
   ============================================================================ */

/**
 * Get current monotonic time in nanoseconds
 */
uint64_t mw_get_time_ns(void);

/**
 * Get current event count
 */
uint64_t mw_get_event_count(void);

/**
 * Get memory currently used by MemWatch (rough estimate)
 */
size_t mw_get_memory_used(void);

#ifdef __cplusplus
}
#endif

#endif /* MEMWATCH_CORE_H */
