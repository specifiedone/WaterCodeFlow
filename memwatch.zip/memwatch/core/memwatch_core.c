#define _GNU_SOURCE
#include "memwatch_core.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <signal.h>
#include <sys/mman.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <time.h>
#include <sys/syscall.h>

/* ============================================================================
   INTERNAL DATA STRUCTURES
   ============================================================================ */

#define MW_PAGE_SIZE 4096
#define MW_MAX_TRACKED_REGIONS 10000
#define MW_EVENT_QUEUE_SIZE 100000

typedef struct {
    void* address;              /* Allocation address */
    size_t size;                /* Allocation size (must be page-aligned) */
    mw_var_meta_t meta;         /* Variable metadata */
    volatile uint8_t in_signal_handler;  /* Atomic flag: currently inside signal handler */
    uint8_t* last_known_value;  /* Snapshot for comparison */
} mw_tracked_region_t;

typedef struct {
    mw_event_t events[MW_EVENT_QUEUE_SIZE];
    size_t head;
    size_t tail;
    size_t count;
    pthread_mutex_t lock;
} mw_event_queue_t;

typedef struct {
    mw_tracked_region_t regions[MW_MAX_TRACKED_REGIONS];
    size_t count;
    pthread_rwlock_t region_lock;
    
    mw_event_queue_t event_queue;
    mw_event_callback_t callback;
    
    int enabled;
    int initialized;
    mw_config_t config;
    
    uint64_t event_count;
    
    struct sigaction old_sigaction;
} mw_core_state_t;

static mw_core_state_t g_core = {0};
static pthread_mutex_t g_init_lock = PTHREAD_MUTEX_INITIALIZER;

/* ============================================================================
   TIMING
   ============================================================================ */

uint64_t mw_get_time_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

static pid_t mw_get_tid(void) __attribute__((unused));
static pid_t mw_get_tid(void) {
    return (pid_t)syscall(SYS_gettid);
}

/* ============================================================================
   SIGNAL HANDLER - THE HEART OF PAGE PROTECTION
   ============================================================================ */

static void mw_sigsegv_handler(int sig, siginfo_t* siginfo, void* context) {
    (void)sig;
    (void)context;
    
    if (!g_core.enabled) {
        goto call_original;
    }

    void* fault_addr = siginfo->si_addr;
    
    /* Try to find the tracked region (read lock only) */
    pthread_rwlock_rdlock(&g_core.region_lock);
    
    mw_tracked_region_t* region = NULL;
    for (size_t i = 0; i < g_core.count; i++) {
        if (fault_addr >= g_core.regions[i].address &&
            fault_addr < (void*)((uintptr_t)g_core.regions[i].address + g_core.regions[i].size)) {
            region = &g_core.regions[i];
            break;
        }
    }
    
    pthread_rwlock_unlock(&g_core.region_lock);
    
    if (!region) {
        goto call_original;
    }

    /* Mark that we're in handler to prevent re-entrance */
    if (__atomic_test_and_set(&region->in_signal_handler, __ATOMIC_SEQ_CST)) {
        goto call_original;  /* Already in handler, don't re-enter */
    }

    /* Capture old value - just store the starting bytes for tracking */
    uint8_t old_value[256];
    size_t capture_size = region->size < sizeof(old_value) ? region->size : sizeof(old_value);
    memcpy(old_value, region->address, capture_size);

    /* Temporarily unprotect the page to allow the write */
    if (mprotect(region->address, region->size, PROT_READ | PROT_WRITE) != 0) {
        __atomic_clear(&region->in_signal_handler, __ATOMIC_SEQ_CST);
        goto call_original;
    }

    /* Signal allowed to proceed - instruction will re-execute and complete the write */
    /* We DON'T re-protect here - we let the write happen */
    /* The next access will trigger another fault if needed */
    
    __atomic_clear(&region->in_signal_handler, __ATOMIC_SEQ_CST);
    
    /* CRITICAL: Return from signal handler. The faulting instruction will re-execute */
    return;

call_original:
    /* Call the original handler if it exists */
    if (g_core.old_sigaction.sa_sigaction) {
        g_core.old_sigaction.sa_sigaction(sig, siginfo, context);
    } else {
        signal(sig, SIG_DFL);
        raise(sig);
    }
}

/* ============================================================================
   INITIALIZATION
   ============================================================================ */

static void mw_init_internal(void) {
    memset(&g_core, 0, sizeof(g_core));
    
    pthread_rwlock_init(&g_core.region_lock, NULL);
    pthread_mutex_init(&g_core.event_queue.lock, NULL);
    
    /* Install signal handler for SIGSEGV */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = mw_sigsegv_handler;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    
    sigaction(SIGSEGV, &sa, &g_core.old_sigaction);
    
    g_core.enabled = 1;
    g_core.initialized = 1;
}

int mw_init(void) {
    pthread_mutex_lock(&g_init_lock);
    
    if (g_core.initialized) {
        pthread_mutex_unlock(&g_init_lock);
        return 0;  /* Already initialized */
    }
    
    mw_init_internal();
    
    pthread_mutex_unlock(&g_init_lock);
    return g_core.initialized ? 0 : -1;
}

void mw_shutdown(void) {
    pthread_mutex_lock(&g_init_lock);
    
    if (!g_core.initialized) {
        pthread_mutex_unlock(&g_init_lock);
        return;
    }
    
    mw_set_tracking_enabled(0);
    
    /* Restore original signal handler */
    sigaction(SIGSEGV, &g_core.old_sigaction, NULL);
    
    /* Unprotect and free all regions */
    pthread_rwlock_wrlock(&g_core.region_lock);
    for (size_t i = 0; i < g_core.count; i++) {
        mprotect(g_core.regions[i].address, g_core.regions[i].size, PROT_READ | PROT_WRITE);
        munmap(g_core.regions[i].address, g_core.regions[i].size);
        if (g_core.regions[i].last_known_value) {
            free(g_core.regions[i].last_known_value);
        }
    }
    g_core.count = 0;
    pthread_rwlock_unlock(&g_core.region_lock);
    
    pthread_rwlock_destroy(&g_core.region_lock);
    pthread_mutex_destroy(&g_core.event_queue.lock);
    
    memset(&g_core, 0, sizeof(g_core));
    
    pthread_mutex_unlock(&g_init_lock);
}

/* ============================================================================
   MEMORY TRACKING
   ============================================================================ */

void* mw_alloc_tracked(size_t size, const mw_var_meta_t* meta) {
    if (!g_core.initialized) mw_init();
    if (!meta) return NULL;
    
    /* Round up to page boundary */
    size_t aligned_size = ((size + MW_PAGE_SIZE - 1) / MW_PAGE_SIZE) * MW_PAGE_SIZE;
    
    /* Allocate memory */
    void* ptr = mmap(NULL, aligned_size, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (ptr == MAP_FAILED) {
        return NULL;
    }
    
    /* Register tracking */
    pthread_rwlock_wrlock(&g_core.region_lock);
    
    if (g_core.count >= MW_MAX_TRACKED_REGIONS) {
        pthread_rwlock_unlock(&g_core.region_lock);
        munmap(ptr, aligned_size);
        return NULL;
    }
    
    mw_tracked_region_t* region = &g_core.regions[g_core.count];
    region->address = ptr;
    region->size = aligned_size;
    region->meta = *meta;
    region->in_signal_handler = 0;
    region->last_known_value = malloc(size);
    
    g_core.count++;
    
    /* Protect the memory as read-only */
    mprotect(ptr, aligned_size, PROT_READ);
    
    pthread_rwlock_unlock(&g_core.region_lock);
    
    return ptr;
}

int mw_free_tracked(void* ptr) {
    if (!ptr) return -1;
    
    pthread_rwlock_wrlock(&g_core.region_lock);
    
    for (size_t i = 0; i < g_core.count; i++) {
        if (g_core.regions[i].address == ptr) {
            /* Unprotect */
            mprotect(ptr, g_core.regions[i].size, PROT_READ | PROT_WRITE);
            
            /* Unmap */
            munmap(ptr, g_core.regions[i].size);
            
            /* Free snapshot */
            if (g_core.regions[i].last_known_value) {
                free(g_core.regions[i].last_known_value);
            }
            
            /* Remove from tracking */
            if (i < g_core.count - 1) {
                g_core.regions[i] = g_core.regions[g_core.count - 1];
            }
            g_core.count--;
            
            pthread_rwlock_unlock(&g_core.region_lock);
            return 0;
        }
    }
    
    pthread_rwlock_unlock(&g_core.region_lock);
    return -1;
}

void* mw_realloc_tracked(void* ptr, size_t new_size) {
    if (!ptr) return mw_alloc_tracked(new_size, &(mw_var_meta_t){});
    
    pthread_rwlock_rdlock(&g_core.region_lock);
    
    mw_tracked_region_t* region = NULL;
    for (size_t i = 0; i < g_core.count; i++) {
        if (g_core.regions[i].address == ptr) {
            region = &g_core.regions[i];
            break;
        }
    }
    
    if (!region) {
        pthread_rwlock_unlock(&g_core.region_lock);
        return NULL;
    }
    
    mw_var_meta_t meta = region->meta;
    pthread_rwlock_unlock(&g_core.region_lock);
    
    mw_free_tracked(ptr);
    return mw_alloc_tracked(new_size, &meta);
}

const mw_var_meta_t* mw_get_meta(void* ptr) {
    if (!ptr) return NULL;
    
    pthread_rwlock_rdlock(&g_core.region_lock);
    
    for (size_t i = 0; i < g_core.count; i++) {
        if (g_core.regions[i].address == ptr) {
            pthread_rwlock_unlock(&g_core.region_lock);
            return &g_core.regions[i].meta;
        }
    }
    
    pthread_rwlock_unlock(&g_core.region_lock);
    return NULL;
}

const mw_var_meta_t* mw_lookup_var_by_address(void* address) {
    if (!address) return NULL;
    
    pthread_rwlock_rdlock(&g_core.region_lock);
    
    for (size_t i = 0; i < g_core.count; i++) {
        if (address >= g_core.regions[i].address &&
            address < (void*)((uintptr_t)g_core.regions[i].address + g_core.regions[i].size)) {
            pthread_rwlock_unlock(&g_core.region_lock);
            return &g_core.regions[i].meta;
        }
    }
    
    pthread_rwlock_unlock(&g_core.region_lock);
    return NULL;
}

/* ============================================================================
   CONFIGURATION
   ============================================================================ */

void mw_set_tracking_enabled(int enabled) {
    g_core.enabled = enabled;
}

int mw_set_config(const mw_config_t* cfg) {
    if (!cfg) return -1;
    g_core.config = *cfg;
    return 0;
}

const mw_config_t* mw_get_config(void) {
    return &g_core.config;
}

/* ============================================================================
   CALLBACKS
   ============================================================================ */

int mw_register_callback(mw_event_callback_t callback) {
    if (!callback) return -1;
    g_core.callback = callback;
    return 0;
}

/* ============================================================================
   SQL TRACKING
   ============================================================================ */

int mw_emit_sql_event(const mw_event_sql_t* event) {
    if (!g_core.enabled || !event) return -1;
    
    mw_set_tracking_enabled(0);  /* Disable during callback */
    
    if (g_core.callback) {
        mw_event_t evt;
        evt.type = MW_EVENT_SQL_QUERY;
        evt.data.sql = *event;
        g_core.callback(&evt);
    }
    
    mw_set_tracking_enabled(1);
    
    g_core.event_count++;
    return 0;
}

/* ============================================================================
   THREAD TRACKING
   ============================================================================ */

int mw_register_thread_local_page(uint64_t thread_id __attribute__((unused))) {
    /* Placeholder for now - will implement thread-local page management */
    return 0;
}

int mw_unregister_thread_local_page(uint64_t thread_id __attribute__((unused))) {
    /* Placeholder for now */
    return 0;
}

/* ============================================================================
   STATISTICS
   ============================================================================ */

uint64_t mw_get_event_count(void) {
    return g_core.event_count;
}

size_t mw_get_memory_used(void) {
    pthread_rwlock_rdlock(&g_core.region_lock);
    
    size_t total = 0;
    for (size_t i = 0; i < g_core.count; i++) {
        total += g_core.regions[i].size;
    }
    
    pthread_rwlock_unlock(&g_core.region_lock);
    return total;
}
