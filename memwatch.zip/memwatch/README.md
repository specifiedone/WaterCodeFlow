# MemWatch - Multi-Language Memory & SQL Tracking

MemWatch is a unified CLI for tracking memory allocations and SQL queries across multiple programming languages. Currently supports **Python** and **Node.js** with a framework for easy addition of new languages.

## Quick Start

### Installation

```bash
./setup.sh
```

This will:
- Build the C core library
- Install Python dependencies
- Compile Node.js bindings
- Verify all tests pass

### Basic Usage

**Track memory in Python:**
```bash
python cli/memwatch_cli.py --language=python --memwatch app.py
```

**Track memory in Node.js:**
```bash
python cli/memwatch_cli.py --language=node --memwatch app.js
```

**Track SQL queries:**
```bash
python cli/memwatch_cli.py --language=python --memwatch-sql app.py
python cli/memwatch_cli.py --language=node --memwatch-sql app.js
```

**Track both memory and SQL:**
```bash
python cli/memwatch_cli.py --language=python --memwatch --memwatch-sql app.py
```

## CLI Flags Reference

### Language Selection (Required)
```
--language=<lang>    Programming language: python, node, javascript
```

### Memory Tracking
```
--memwatch           Enable memory tracking (page protection)
--memwatch-locals    Track local variables only
--memwatch-globals   Track global variables only
--memwatch-vars=x,y  Track specific variables by name
```

### SQL Tracking
```
--memwatch-sql       Enable SQL query tracking
--memwatch-threads   Track multi-threaded execution
```

### Scope Limiting
```
--track-file=app.py       Only track this file
--track-module=myapp      Only track this module
```

### Output & Debug
```
--memwatch-debug           Show debug output
--memwatch-output=file.txt Write results to file
--memwatch-store-bytes=N   Store N bytes of data (if positive)
```

## Supported Languages

### Python ✅
- **Status:** Fully implemented
- **Technology:** C core via ctypes bindings
- **Features:** Memory tracking, SQL tracking, variable tracking, threading support
- **SQL Libraries:** sqlite3, mysql-connector-python, psycopg2

### Node.js/JavaScript ✅
- **Status:** Fully implemented
- **Technology:** JavaScript runtime with method interception
- **Features:** Memory tracking, SQL tracking, file/module scoping
- **SQL Libraries:** sqlite3, better-sqlite3, mysql2, pg

### Other Languages
- **Status:** Framework stubs ready for implementation
- **Supported:** Go, Rust, C++, C#, Java, Ruby, PHP, Kotlin
- **Roadmap:** Each can be implemented independently

## Adding Support for a New Language

### Step 1: Create the Adapter Module

Create `adapters/memwatch_adapter_<language>.py`:

```python
"""MemWatch adapter for <Language>"""

import subprocess
import sys
import json
import os
import tempfile

_config = {}
_initialized = False

def initialize(config):
    """Initialize MemWatch for <Language>"""
    global _config, _initialized
    _config = config
    _initialized = True
    if config.get('debug'):
        print(f"[<Language> Adapter] Initialized")

def run_script(script, args, config):
    """Execute a <Language> script with MemWatch tracking"""
    if not _initialized:
        print("❌ Adapter not initialized", file=sys.stderr)
        return 1
    
    if not os.path.exists(script):
        print(f"❌ Script not found: {script}", file=sys.stderr)
        return 1
    
    try:
        # Create config file for runtime
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(config, f)
            config_file = f.name
        
        try:
            # Execute via <language>-specific runtime
            runtime_path = os.path.join(os.path.dirname(__file__), 'memwatch_<lang>.js')
            cmd = ['<language-executable>', runtime_path, config_file, script] + (args or [])
            result = subprocess.run(cmd)
            return result.returncode
        finally:
            try:
                os.unlink(config_file)
            except:
                pass
    
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        return 1

def shutdown():
    """Cleanup"""
    global _initialized
    if _initialized:
        _initialized = False
        if _config.get('debug'):
            print(f"[<Language> Adapter] Shutdown")
```

### Step 2: Create the Language Runtime

Create `adapters/memwatch_<lang>.<ext>`:

```javascript
// For JavaScript-like languages
// Implement memory tracking and SQL interception
// Follow the pattern in memwatch.js

class MemWatch {
    constructor(config) {
        this.config = config;
        // Initialize tracking
    }
    
    setupSQLTracking() {
        // Hook into SQL libraries
    }
    
    executeScript(scriptPath, args) {
        // Load and execute script with tracking
    }
}
```

### Step 3: Register the Language

Edit `cli/memwatch_cli.py` and add to `SUPPORTED_LANGUAGES`:

```python
SUPPORTED_LANGUAGES = {
    'python': 'adapters.memwatch_adapter_python',
    'node': 'adapters.memwatch_adapter_node',
    'javascript': 'adapters.memwatch_adapter_node',
    '<newlang>': 'adapters.memwatch_adapter_<newlang>',  # Add this
    # ... other languages
}
```

### Step 4: Create Tests

Create `tests/test_<lang>_implementation.py`:

```python
import pytest
import subprocess
import tempfile

class TestNewLanguage:
    def test_basic_execution(self):
        """Test: Script executes"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.<ext>', delete=False) as f:
            f.write('print("Hello"); exit(0);')
            script = f.name
        
        result = subprocess.run(
            ['python', 'cli/memwatch_cli.py',
             '--language=<newlang>',
             script],
            capture_output=True,
            timeout=5
        )
        assert result.returncode == 0
```

### Step 5: Test & Verify

```bash
# Run new language tests
pytest tests/test_<lang>_implementation.py -v

# Run full test suite
pytest tests/ -v

# Manual test
python cli/memwatch_cli.py --language=<newlang> --memwatch-debug script.<ext>
```

## Project Structure

```
memwatch/
├── cli/
│   ├── memwatch_cli.py          # Main CLI entry point
│   ├── python_cli.py            # Python language CLI
│   └── node_cli.js              # Node.js language CLI
├── adapters/
│   ├── memwatch_adapter_python.py
│   ├── memwatch_adapter_node.py
│   ├── memwatch.js              # Node.js runtime
│   └── memwatch_adapter_*.py    # Other language adapters
├── core/
│   ├── memwatch_core.c          # C memory tracking core
│   └── memwatch_core.h
├── tests/
│   ├── test_*.py               # All test files
│   └── fixtures/               # Test data
├── setup.sh                     # Project setup
├── clean.sh                     # Build cleanup
└── README.md                    # This file
```

## How It Works

### Memory Tracking (Python)
1. C core uses `mprotect()` to protect memory pages
2. On access, SIGSEGV signal handler captures allocation info
3. Local variable relocation tracks stack objects
4. Python adapter wraps C core via ctypes

### Memory Tracking (Node.js)
1. Takes periodic `process.memoryUsage()` snapshots
2. Tracks heap growth between snapshots
3. Optional console interception for event-based tracking

### SQL Tracking (Python)
1. Wraps sqlite3 connection objects
2. Intercepts cursor.execute() calls
3. Logs query, parameters, call site, timing

### SQL Tracking (Node.js)
1. Hooks Database.prototype methods before script loads
2. Intercepts `db.run()`, `db.query()`, `db.prepare()` methods
3. Tracks query string, source library, timestamp
4. Works with: sqlite3, better-sqlite3, mysql2, pg

## Testing

### Run All Tests
```bash
pytest tests/ -v --timeout=10
```

### Run Specific Test Suite
```bash
pytest tests/test_node_implementation.py -v
pytest tests/test_memory_tracking.py -v
pytest tests/test_sql_interception.py -v
```

### Run Single Test
```bash
pytest tests/test_node_implementation.py::TestNodeJSRealImplementation::test_nodejs_basic_execution -v
```

## Performance

### Baseline (No Tracking)
- Python: ~5-10ms overhead
- Node.js: ~2-5ms overhead

### With Memory Tracking
- Python: ~25-50ms additional
- Node.js: ~10-20ms additional

### With SQL Tracking
- Python: ~5-10ms per query
- Node.js: ~2-5ms per query

## Troubleshooting

### "Node.js not found"
```bash
apt-get install nodejs npm
```

### "Python module not found"
```bash
pip install -r requirements.txt
```

### "C library compilation failed"
```bash
./setup.sh
```

### Tests failing
```bash
./clean.sh
./setup.sh
pytest tests/ -v
```

## Architecture

### Unified CLI (`cli/memwatch_cli.py`)
- Parses arguments
- Routes to language adapter
- Handles configuration
- No language-specific logic

### Language Adapters (`adapters/memwatch_adapter_*.py`)
- Language-specific initialization
- Config passing to runtime
- Error handling
- Cleanup

### Language Runtimes
- **Python:** C core integration via ctypes
- **Node.js:** JavaScript runtime with hooking
- **Others:** Language-specific implementations

### C Core (`core/memwatch_core.c`)
- Page protection (mprotect)
- Signal handling (SIGSEGV)
- Memory tracking
- Thread-safe operations

## Contributing

To add support for a new language:

1. Read "Adding Support for a New Language" above
2. Implement adapter module
3. Create language runtime
4. Add tests
5. Register in CLI
6. Submit PR

## License

This project is part of WaterCodeFlow.

## Support

For issues, questions, or contributions, please refer to the main repository.
