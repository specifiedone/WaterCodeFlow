#!/bin/bash
# MemWatch Setup Script - Installs dependencies and builds project

set -e

echo "🔧 MemWatch Setup"
echo "=================="

cd "$(dirname "$0")"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check Python
echo -e "${YELLOW}Checking Python...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python3 not found. Please install Python 3.8+${NC}"
    exit 1
fi
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo -e "${GREEN}✓ Python ${PYTHON_VERSION}${NC}"

# Check Node.js (optional)
echo -e "${YELLOW}Checking Node.js...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo -e "${GREEN}✓ Node.js ${NODE_VERSION}${NC}"
else
    echo -e "${YELLOW}⚠ Node.js not found (optional)${NC}"
fi

# Install Python dependencies
echo -e "${YELLOW}Installing Python dependencies...${NC}"
pip install -q pytest pytest-timeout 2>/dev/null || true
echo -e "${GREEN}✓ Python dependencies installed${NC}"

# Build C extension (if Node.js available)
if command -v node &> /dev/null; then
    echo -e "${YELLOW}Building Node.js C extension...${NC}"
    if [ -f "binding.gyp" ]; then
        npm install --no-save 2>/dev/null || true
        ./node.sh 2>&1 || echo "⚠ Node.js build optional"
    fi
    echo -e "${GREEN}✓ Node.js setup complete${NC}"
fi

# Run tests
echo -e "${YELLOW}Running test suite...${NC}"
python3 -m pytest tests/ -q --tb=short 2>/dev/null || true