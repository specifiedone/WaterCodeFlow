"""MemWatch Python CLI Entry Point"""

import sys
import os
import argparse
import threading
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from adapters import memwatch_adapter as mw

def parse_args():
    """Parse MemWatch CLI flags"""
    parser = argparse.ArgumentParser(description='MemWatch - Memory and SQL Tracking')
    
    parser.add_argument('script', help='Python script to execute')
    parser.add_argument('--memwatch', action='store_true', help='Enable memory tracking')
    parser.add_argument('--memwatch-locals', action='store_true', help='Track local variables')
    parser.add_argument('--memwatch-globals', action='store_true', help='Track global variables')
    parser.add_argument('--memwatch-all', action='store_true', help='Track all memory')
    parser.add_argument('--memwatch-vars', type=str, help='Track specific variables (comma-separated)')
    parser.add_argument('--memwatch-threads', action='store_true', help='Include thread info')
    parser.add_argument('--memwatch-sql', action='store_true', help='Track SQL queries')
    parser.add_argument('--memwatch-output', type=str, help='Output file for events')
    parser.add_argument('--memwatch-debug', action='store_true', help='Enable debug output')
    parser.add_argument('--memwatch-store-bytes', type=int, default=-1, help='Max bytes to store (-1 for unlimited)')
    
    args, remaining = parser.parse_known_args()
    return args, remaining

def main():
    """Main entry point"""
    args, remaining_args = parse_args()
    
    # Initialize MemWatch core
    mw.initialize()
    
    # Configure based on flags
    config = {
        'track_memory': 1 if (args.memwatch or args.memwatch_all) else 0,
        'track_locals': 1 if (args.memwatch_locals or args.memwatch_all) else 0,
        'track_globals': 1 if (args.memwatch_globals or args.memwatch_all) else 0,
        'track_threads': 1 if args.memwatch_threads else 0,
        'track_sql': 1 if args.memwatch_sql else 0,
        'debug': 1 if args.memwatch_debug else 0,
        'store_bytes': args.memwatch_store_bytes,
        'output_file': args.memwatch_output,
    }
    
    mw.set_config(config)
    
    # Wrap databases if SQL tracking is enabled
    if args.memwatch_sql:
        mw.wrap_sqlite3()
        mw.wrap_mysql()
    
    # Load and execute the user script
    script_path = Path(args.script)
    if not script_path.exists():
        print(f"Error: Script '{args.script}' not found", file=sys.stderr)
        return 1
    
    # Read script
    with open(script_path, 'r') as f:
        script_code = f.read()
    
    # Prepare execution environment
    exec_globals = {
        '__name__': '__main__',
        '__file__': str(script_path),
        '__builtins__': __builtins__,
    }
    
    try:
        # Execute the script
        exec(script_code, exec_globals)
    except Exception as e:
        print(f"Error executing script: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1
    finally:
        # Shutdown MemWatch
        mw.shutdown()
    
    return 0

if __name__ == '__main__':
    sys.exit(main())
