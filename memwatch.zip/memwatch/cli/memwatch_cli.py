#!/usr/bin/env python3
"""
MemWatch Master CLI — Language-Agnostic Entry Point

Supports: Python, JavaScript, Go, Rust, C++, C#, Java, Ruby, PHP, Kotlin
Framework designed for easy addition of new languages.
"""

import sys
import os
import argparse
import importlib
import json
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class MemWatchCLI:
    """Unified CLI for all supported languages"""
    
    # Supported languages and their adapters
    SUPPORTED_LANGUAGES = {
        'python': 'adapters.memwatch_adapter_python',
        'node': 'adapters.memwatch_adapter_node',
        'javascript': 'adapters.memwatch_adapter_node',
        'go': 'adapters.memwatch_adapter_go',
        'rust': 'adapters.memwatch_adapter_rust',
        'cpp': 'adapters.memwatch_adapter_cpp',
        'csharp': 'adapters.memwatch_adapter_csharp',
        'java': 'adapters.memwatch_adapter_java',
        'ruby': 'adapters.memwatch_adapter_ruby',
        'php': 'adapters.memwatch_adapter_php',
        'kotlin': 'adapters.memwatch_adapter_kotlin',
    }
    
    def __init__(self):
        self.language = None
        self.adapter = None
        self.config = {}
    
    def parse_args(self):
        """Parse command-line arguments"""
        parser = argparse.ArgumentParser(
            description='MemWatch - Multi-Language Memory and SQL Tracking',
            usage='memwatch --language=<lang> [flags] script [script_args]'
        )
        
        # Language selection
        parser.add_argument(
            '--language',
            required=True,
            choices=list(self.SUPPORTED_LANGUAGES.keys()),
            help=f'Programming language: {", ".join(self.SUPPORTED_LANGUAGES.keys())}'
        )
        
        # Script to execute
        parser.add_argument('script', help='Script/file to execute')
        
        # Tracking scope
        parser.add_argument(
            '--track-file',
            type=str,
            help='Only track variables in this file (can specify multiple: file1.py,file2.py)'
        )
        
        parser.add_argument(
            '--track-module',
            type=str,
            help='Only track variables in this module (e.g., myapp, app.core)'
        )
        
        # Memory tracking
        parser.add_argument(
            '--memwatch',
            action='store_true',
            help='Enable memory tracking (page protection)'
        )
        
        parser.add_argument(
            '--memwatch-locals',
            action='store_true',
            help='Track local variables only'
        )
        
        parser.add_argument(
            '--memwatch-globals',
            action='store_true',
            help='Track global variables only'
        )
        
        parser.add_argument(
            '--memwatch-all',
            action='store_true',
            help='Track all memory (locals + globals + SQL)'
        )
        
        parser.add_argument(
            '--memwatch-vars',
            type=str,
            help='Track specific variables (comma-separated: x,y,z)'
        )
        
        # SQL tracking
        parser.add_argument(
            '--memwatch-sql',
            action='store_true',
            help='Enable SQL query tracking'
        )
        
        # Additional options
        parser.add_argument(
            '--memwatch-threads',
            action='store_true',
            help='Include thread information'
        )
        
        parser.add_argument(
            '--memwatch-output',
            type=str,
            help='Output file for events (JSON)'
        )
        
        parser.add_argument(
            '--memwatch-debug',
            action='store_true',
            help='Enable debug output'
        )
        
        parser.add_argument(
            '--memwatch-store-bytes',
            type=int,
            default=-1,
            help='Max bytes to store per value (-1 for unlimited)'
        )
        
        # Parse known args to allow script args to pass through
        args, remaining = parser.parse_known_args()
        
        return args, remaining
    
    def load_adapter(self, language):
        """Load language-specific adapter"""
        if language not in self.SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported language: {language}. Supported: {list(self.SUPPORTED_LANGUAGES.keys())}")
        
        adapter_module_name = self.SUPPORTED_LANGUAGES[language]
        
        try:
            # Try to import the adapter
            adapter_module = importlib.import_module(adapter_module_name)
            return adapter_module
        except ImportError:
            # If adapter not found, return a stub that will explain what's needed
            self._print_adapter_stub_info(language, adapter_module_name)
            raise
    
    def _print_adapter_stub_info(self, language, module_name):
        """Print info about missing adapter"""
        print(f"❌ Adapter for {language} not found: {module_name}", file=sys.stderr)
        print(f"\nTo add support for {language}, create:", file=sys.stderr)
        print(f"  adapters/memwatch_adapter_{language}.py", file=sys.stderr)
        print(f"\nWith interface:", file=sys.stderr)
        print(f"  def initialize(config)", file=sys.stderr)
        print(f"  def run_script(script, args, config)", file=sys.stderr)
        print(f"  def shutdown()", file=sys.stderr)
    
    def build_config(self, args):
        """Build configuration from CLI args"""
        config = {
            'language': args.language,
            'track_memory': 1 if (args.memwatch or args.memwatch_all) else 0,
            'track_locals': 1 if (args.memwatch_locals or args.memwatch_all) else 0,
            'track_globals': 1 if (args.memwatch_globals or args.memwatch_all) else 0,
            'track_threads': 1 if args.memwatch_threads else 0,
            'track_sql': 1 if (args.memwatch_sql or args.memwatch_all) else 0,
            'debug': 1 if args.memwatch_debug else 0,
            'store_bytes': args.memwatch_store_bytes,
            'output_file': args.memwatch_output,
            'track_file': args.track_file,
            'track_module': args.track_module,
            'specific_vars': args.memwatch_vars.split(',') if args.memwatch_vars else [],
        }
        return config
    
    def run(self):
        """Main entry point"""
        try:
            args, remaining_args = self.parse_args()
            
            # Load language adapter
            adapter = self.load_adapter(args.language)
            
            # Build configuration
            config = self.build_config(args)
            
            if config['debug']:
                print(f"[MemWatch] Language: {args.language}")
                print(f"[MemWatch] Script: {args.script}")
                print(f"[MemWatch] Config: {json.dumps(config, indent=2)}")
            
            # Initialize adapter
            adapter.initialize(config)
            
            try:
                # Run the script with the adapter
                exit_code = adapter.run_script(args.script, remaining_args, config)
                return exit_code
            finally:
                # Cleanup
                adapter.shutdown()
        
        except Exception as e:
            print(f"❌ Error: {e}", file=sys.stderr)
            return 1


def main():
    """Entry point"""
    cli = MemWatchCLI()
    exit_code = cli.run()
    sys.exit(exit_code)


if __name__ == '__main__':
    main()
