#!/usr/bin/env node
/**
 * MemWatch Node.js CLI Entry Point
 */

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const adapter = require('../adapters/memwatch_adapter');

/**
 * Parse MemWatch CLI flags
 */
function parseArgs() {
    const args = process.argv.slice(2);
    const flags = {
        script: null,
        memwatch: false,
        memwatchLocals: false,
        memwatchGlobals: false,
        memwatchAll: false,
        memwatchVars: [],
        memwatchThreads: false,
        memwatchSql: false,
        memwatchOutput: null,
        memwatchDebug: false,
        memwatchStoreBytes: -1,
    };
    
    const remaining = [];
    
    for (let i = 0; i < args.length; i++) {
        const arg = args[i];
        
        if (arg === '--memwatch') {
            flags.memwatch = true;
        } else if (arg === '--memwatch-locals') {
            flags.memwatchLocals = true;
        } else if (arg === '--memwatch-globals') {
            flags.memwatchGlobals = true;
        } else if (arg === '--memwatch-all') {
            flags.memwatchAll = true;
        } else if (arg.startsWith('--memwatch-vars=')) {
            flags.memwatchVars = arg.split('=')[1].split(',');
        } else if (arg === '--memwatch-threads') {
            flags.memwatchThreads = true;
        } else if (arg === '--memwatch-sql') {
            flags.memwatchSql = true;
        } else if (arg.startsWith('--memwatch-output=')) {
            flags.memwatchOutput = arg.split('=')[1];
        } else if (arg === '--memwatch-debug') {
            flags.memwatchDebug = true;
        } else if (arg.startsWith('--memwatch-store-bytes=')) {
            flags.memwatchStoreBytes = parseInt(arg.split('=')[1], 10);
        } else if (arg.startsWith('--')) {
            remaining.push(arg);
        } else if (!flags.script) {
            flags.script = arg;
        } else {
            remaining.push(arg);
        }
    }
    
    return { flags, remaining };
}

/**
 * Main function
 */
function main() {
    const { flags, remaining } = parseArgs();
    
    if (!flags.script) {
        console.error('Usage: memwatch <script.js> [flags]');
        return 1;
    }
    
    // Initialize MemWatch core
    try {
        adapter.initialize();
    } catch (e) {
        console.error('Failed to initialize MemWatch:', e.message);
        return 1;
    }
    
    // Configure based on flags
    const config = {
        trackMemory: flags.memwatch || flags.memwatchAll ? 1 : 0,
        trackLocals: flags.memwatchLocals || flags.memwatchAll ? 1 : 0,
        trackGlobals: flags.memwatchGlobals || flags.memwatchAll ? 1 : 0,
        trackThreads: flags.memwatchThreads ? 1 : 0,
        trackSql: flags.memwatchSql ? 1 : 0,
        debug: flags.memwatchDebug ? 1 : 0,
        storeBytes: flags.memwatchStoreBytes,
        outputFile: flags.memwatchOutput,
    };
    
    adapter.setConfig(config);
    
    // Wrap databases if SQL tracking is enabled
    if (flags.memwatchSql) {
        adapter.wrapSqlite3();
        adapter.wrapMysql2();
    }
    
    // Load and execute the user script
    const scriptPath = path.resolve(flags.script);
    
    if (!fs.existsSync(scriptPath)) {
        console.error(`Error: Script '${flags.script}' not found`);
        return 1;
    }
    
    try {
        // Read script
        const scriptCode = fs.readFileSync(scriptPath, 'utf-8');
        
        // Prepare execution environment
        const sandbox = {
            __dirname: path.dirname(scriptPath),
            __filename: scriptPath,
            process: process,
            console: console,
            require: require,
            Buffer: Buffer,
            setTimeout: setTimeout,
            setInterval: setInterval,
            setImmediate: setImmediate,
            clearTimeout: clearTimeout,
            clearInterval: clearInterval,
            clearImmediate: clearImmediate,
            global: global,
        };
        
        // Execute the script
        vm.runInNewContext(scriptCode, sandbox, {
            filename: scriptPath,
            timeout: undefined,
        });
        
    } catch (e) {
        console.error(`Error executing script: ${e.message}`);
        console.error(e.stack);
        return 1;
    } finally {
        // Shutdown MemWatch
        try {
            adapter.shutdown();
        } catch (e) {
            console.error('Error during shutdown:', e.message);
        }
    }
    
    return 0;
}

process.exit(main());
