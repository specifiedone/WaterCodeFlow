# MemWatch Data Storage & Usage Guide

Complete guide on how MemWatch stores data, how to access it, and how to use the tracked information.

## 📊 Quick Start

### Basic Usage with Output

```bash
# Track memory and save to file
python cli/memwatch_cli.py --language=python --memwatch --memwatch-output=trace.json app.py

# Track SQL queries
python cli/memwatch_cli.py --language=python --memwatch-sql --memwatch-output=trace.json app.py

# Track both with debug output
python cli/memwatch_cli.py --language=python --memwatch --memwatch-sql --memwatch-debug --memwatch-output=trace.json app.py
```

---

## 📁 Data Storage Methods

### Method 1: In-Memory (Default)

Data stored in memory during execution, lost when script exits:
- Tracked in C core ring buffer
- Tracked in JavaScript/Python arrays
- Speed: Fastest
- Persistence: None

```bash
python cli/memwatch_cli.py --language=python --memwatch app.py
```

### Method 2: JSON File Export

All data saved to structured JSON file:
- Permanent storage
- Can be analyzed later
- Timestamped events
- Complete trace

```bash
python cli/memwatch_cli.py --language=python --memwatch --memwatch-output=trace.json app.py
```

**Output file contains:**
- Metadata (language, duration, config)
- All memory events (variable changes)
- All SQL events (queries executed)
- Summary statistics

---

## 📋 JSON Output Format

```json
{
  "metadata": {
    "language": "python",
    "started_at": "2026-02-01T12:34:56.789Z",
    "duration_ms": 5234,
    "track_file": null,
    "track_module": null,
    "store_bytes": -1
  },
  
  "memory_events": [
    {
      "timestamp_ms": 100,
      "sequence": 1,
      "variable_name": "result",
      "function": "fibonacci",
      "file": "app.py",
      "line": 42,
      "old_value": "0",
      "new_value": "6765",
      "value_bytes": 8,
      "thread_id": "main"
    }
  ],
  
  "sql_events": [
    {
      "timestamp_ms": 250,
      "query": "INSERT INTO users (id, name) VALUES (1, 'Alice')",
      "params": [],
      "source": "sqlite3.run",
      "rows_affected": 1
    }
  ],
  
  "summary": {
    "total_memory_events": 42,
    "total_sql_events": 7,
    "memory_growth_bytes": 5120,
    "variables_tracked": ["result", "data", "count"],
    "tables_modified": ["users", "logs"],
    "queries_by_type": {
      "INSERT": 3,
      "UPDATE": 2,
      "SELECT": 2
    }
  }
}
```

---

## 🔍 How to Use Tracked Data

### Read and Analyze

```python
import json

# Load the trace file
with open('trace.json', 'r') as f:
    data = json.load(f)

# Access memory events
for event in data['memory_events']:
    print(f"{event['variable_name']} at {event['file']}:{event['line']}")
    print(f"  Changed: {event['old_value']} → {event['new_value']}")

# Access SQL events  
for sql in data['sql_events']:
    print(f"[{sql['timestamp_ms']}ms] {sql['query']}")

# Check summary
summary = data['summary']
print(f"Total memory changes: {summary['total_memory_events']}")
print(f"Memory grew by: {summary['memory_growth_bytes']} bytes")
```

### Example: Find Memory Leaks

```python
import json

with open('trace.json') as f:
    data = json.load(f)

# Variables that keep growing
from collections import defaultdict
var_sizes = defaultdict(list)

for event in data['memory_events']:
    var = event['variable_name']
    size = event.get('value_bytes', 0)
    var_sizes[var].append(size)

# Check which variables are growing
for var, sizes in var_sizes.items():
    if len(sizes) > 1:
        growth = sizes[-1] - sizes[0]
        if growth > 1000:
            print(f"⚠️  {var} grew by {growth} bytes!")
```

### Example: SQL Analysis

```python
import json
from collections import Counter

with open('trace.json') as f:
    data = json.load(f)

# Count operation types
ops = Counter()
for sql in data['sql_events']:
    if 'INSERT' in sql['query'].upper():
        ops['INSERT'] += 1
    elif 'UPDATE' in sql['query'].upper():
        ops['UPDATE'] += 1
    elif 'DELETE' in sql['query'].upper():
        ops['DELETE'] += 1
    elif 'SELECT' in sql['query'].upper():
        ops['SELECT'] += 1

print("SQL Operations:")
for op, count in ops.most_common():
    print(f"  {op}: {count}")
```

---

## 🎯 Practical Examples

### Track Sensitive Variables Only

```bash
python cli/memwatch_cli.py \
  --language=python \
  --memwatch \
  --memwatch-vars=password,api_key,token \
  --memwatch-output=sensitive.json \
  app.py
```

Result: Only `password`, `api_key`, `token` changes recorded.

**Use case**: Security auditing, compliance

### Track Specific File Only

```bash
python cli/memwatch_cli.py \
  --language=python \
  --memwatch \
  --track-file=database.py \
  --memwatch-output=db_trace.json \
  app.py
```

Result: Only changes in `database.py` recorded.

**Use case**: Debug specific module

### Track Locals Only

```bash
python cli/memwatch_cli.py \
  --language=python \
  --memwatch \
  --memwatch-locals \
  --memwatch-output=locals.json \
  app.py
```

Result: Only local variables tracked (no globals).

**Use case**: Function profiling

### Full Audit Trail

```bash
python cli/memwatch_cli.py \
  --language=python \
  --memwatch \
  --memwatch-sql \
  --memwatch-threads \
  --memwatch-debug \
  --memwatch-output=full_audit.json \
  app.py
```

Result: Everything tracked with debug output.

**Use case**: Complete system audit

---

## ⚙️ Configuration Options

### Output Control

| Flag | Purpose |
|------|---------|
| `--memwatch-output=file.json` | Save to JSON file |
| `--memwatch-store-bytes=512` | Store max 512 bytes per value |
| `--memwatch-store-bytes=-1` | Store unlimited bytes |
| `--memwatch-debug` | Print debug output |

### What Gets Tracked

| Flag | Tracks |
|------|--------|
| `--memwatch` | Memory changes |
| `--memwatch-sql` | SQL queries |
| `--memwatch-threads` | Thread info |
| `--memwatch-all` | Everything |

### Scope Control

| Flag | Effect |
|------|--------|
| `--track-file=app.py` | Only this file |
| `--track-module=core` | Only this module |
| `--memwatch-vars=x,y` | Only these variables |
| `--memwatch-locals` | Local vars only |
| `--memwatch-globals` | Global vars only |

---

## 📊 Data Processing Recipes

### Print Timeline

```python
import json

with open('trace.json') as f:
    data = json.load(f)

print("=== MEMORY EVENTS TIMELINE ===")
for event in sorted(data['memory_events'], key=lambda x: x['timestamp_ms']):
    ts = event['timestamp_ms']
    var = event['variable_name']
    old = event['old_value'][:20] if event['old_value'] else 'None'
    new = event['new_value'][:20] if event['new_value'] else 'None'
    print(f"{ts:5d}ms | {var:15s} | {old:20s} → {new:20s}")
```

### Group by File

```python
import json
from collections import defaultdict

with open('trace.json') as f:
    data = json.load(f)

by_file = defaultdict(list)
for event in data['memory_events']:
    file = event['file']
    by_file[file].append(event)

for file in sorted(by_file.keys()):
    print(f"\n{file}: {len(by_file[file])} changes")
    for event in by_file[file][:3]:
        print(f"  Line {event['line']}: {event['variable_name']}")
```

### Find Changes by Variable

```python
import json

with open('trace.json') as f:
    data = json.load(f)

var = 'result'  # Change this
changes = [e for e in data['memory_events'] if e['variable_name'] == var]

print(f"{var} changed {len(changes)} times:")
for i, event in enumerate(changes, 1):
    print(f"  {i}. {event['old_value']} → {event['new_value']} at {event['file']}:{event['line']}")
```

### SQL Summary Report

```python
import json

with open('trace.json') as f:
    data = json.load(f)

summary = data['summary']
print(f"""
SQL REPORT
==========
Total queries: {summary.get('total_sql_events', 0)}
Operations:
""")

for op_type, count in summary.get('queries_by_type', {}).items():
    print(f"  {op_type}: {count}")

print(f"\nTables modified: {', '.join(summary.get('tables_modified', []))}")
```

---

## 🚀 Advanced Usage

### Continuous Monitoring

```bash
# Run every 5 minutes and collect traces
while true; do
  python cli/memwatch_cli.py --language=python --memwatch \
    --memwatch-output=trace_$(date +%s).json app.py
  sleep 300
done
```

### Compare Two Runs

```python
import json
import sys

def load_trace(file):
    with open(file) as f:
        return json.load(f)

trace1 = load_trace('trace1.json')
trace2 = load_trace('trace2.json')

print(f"Trace 1: {trace1['summary']['total_memory_events']} events")
print(f"Trace 2: {trace2['summary']['total_memory_events']} events")

if trace2['summary']['memory_growth_bytes'] > trace1['summary']['memory_growth_bytes']:
    diff = trace2['summary']['memory_growth_bytes'] - trace1['summary']['memory_growth_bytes']
    print(f"⚠️  Memory growth increased by {diff} bytes")
```

### Export to CSV

```python
import json
import csv

with open('trace.json') as f:
    data = json.load(f)

# Export memory events
with open('memory_events.csv', 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['timestamp_ms', 'variable_name', 'file', 'line', 'old_value', 'new_value'])
    writer.writeheader()
    for event in data['memory_events']:
        writer.writerow({
            'timestamp_ms': event['timestamp_ms'],
            'variable_name': event['variable_name'],
            'file': event['file'],
            'line': event['line'],
            'old_value': event['old_value'],
            'new_value': event['new_value']
        })

# Export SQL events
with open('sql_events.csv', 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['timestamp_ms', 'query', 'source'])
    writer.writeheader()
    for sql in data['sql_events']:
        writer.writerow({
            'timestamp_ms': sql['timestamp_ms'],
            'query': sql['query'],
            'source': sql['source']
        })

print("Exported to memory_events.csv and sql_events.csv")
```

---

## 💡 Best Practices

1. **Use scoping** - Track only what matters to reduce noise
2. **Save to file** - Use `--memwatch-output` for permanent records
3. **Enable debug** - Use `--memwatch-debug` while developing
4. **Combine tracking** - Use `--memwatch --memwatch-sql` for complete picture
5. **Process programmatically** - Write Python scripts to analyze JSON
6. **Store bytes** - Use `--memwatch-store-bytes=512` to save space for large objects
7. **Archive traces** - Keep historical traces for comparison

---

## 📚 Commands Reference

```bash
# Basic memory tracking
python cli/memwatch_cli.py --language=python --memwatch app.py

# Save to file
python cli/memwatch_cli.py --language=python --memwatch --memwatch-output=trace.json app.py

# Track SQL
python cli/memwatch_cli.py --language=python --memwatch-sql app.py

# Track both
python cli/memwatch_cli.py --language=python --memwatch --memwatch-sql app.py

# Debug output
python cli/memwatch_cli.py --language=python --memwatch --memwatch-debug app.py

# Specific variables
python cli/memwatch_cli.py --language=python --memwatch --memwatch-vars=x,y,z app.py

# Specific file
python cli/memwatch_cli.py --language=python --memwatch --track-file=app.py app.py

# Specific module
python cli/memwatch_cli.py --language=python --memwatch --track-module=myapp app.py

# Locals only
python cli/memwatch_cli.py --language=python --memwatch --memwatch-locals app.py

# Everything
python cli/memwatch_cli.py --language=python --memwatch --memwatch-sql --memwatch-threads --memwatch-all app.py
```

---

## Questions?

See the main [README.md](README.md) for CLI reference or run `python cli/memwatch_cli.py --help`
