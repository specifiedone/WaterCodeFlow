"""SQL tracking tests for Node.js MemWatch adapter"""

import pytest
import subprocess
import os
import tempfile


class TestNodeJSSQLTracking:
    """Test SQL tracking in Node.js"""
    
    def test_sql_flag_parsing(self):
        """Test: --memwatch-sql flag is parsed"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('console.log("Test"); process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch-sql',
                 '--memwatch-debug',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_memory_and_sql_combined(self):
        """Test: Memory and SQL flags work together"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('let x = [1,2,3]; console.log(x.length); process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch',
                 '--memwatch-sql',
                 '--memwatch-debug',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_sql_with_track_file(self):
        """Test: SQL tracking with file scoping"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch-sql',
                 '--track-file=app.js',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_sql_with_track_module(self):
        """Test: SQL tracking with module scoping"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch-sql',
                 '--track-module=app',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_instrumentation_methods_exist(self):
        """Test: SQL instrumentation methods in runtime"""
        result = subprocess.run(
            ['grep', '-c', 'trackSqlQuery', 'adapters/memwatch.js'],
            capture_output=True,
            timeout=5,
            cwd='/workspaces/WaterCodeFlow/memwatch'
        )
        count = int(result.stdout.decode().strip())
        assert count > 0
    
    def test_sql_config_accepted(self):
        """Test: Adapter accepts SQL config"""
        result = subprocess.run(
            ['python', '-c', 'from adapters.memwatch_adapter_node import initialize; initialize({"debug": True, "track_sql": 1}); print("OK")'],
            capture_output=True,
            timeout=5,
            cwd='/workspaces/WaterCodeFlow/memwatch'
        )
        assert result.returncode == 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
