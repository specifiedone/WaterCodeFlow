"""
MemWatch Integration Tests - SQL Interception

Real execution tests for SQL query tracking, parameter capture,
call site resolution, and thread attribution.
"""

import sys
import os
import pytest
import threading
import time
import sqlite3
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from adapters import memwatch_adapter as mw


class TestSqlInterception:
    """Test SQL query tracking"""
    
    def test_sqlite_tracking_basic(self):
        """Test basic SQLite query tracking"""
        mw.initialize()
        
        try:
            mw.set_config({'track_sql': 1})
            mw.wrap_sqlite3()
            
            # Create in-memory database
            conn = sqlite3.connect(':memory:')
            cursor = conn.cursor()
            
            # Execute a query
            cursor.execute('CREATE TABLE test (id INTEGER, name TEXT)')
            cursor.execute('INSERT INTO test VALUES (1, ?)', ('Alice',))
            
            initial_count = mw.mw_get_event_count()
            
            # Execute another query
            cursor.execute('SELECT * FROM test WHERE id = ?', (1,))
            result = cursor.fetchone()
            
            final_count = mw.mw_get_event_count()
            
            # Should have tracked the query
            assert final_count > initial_count, "SQL queries should be tracked"
            assert result == (1, 'Alice'), "Query should return correct result"
            
            conn.close()
        
        finally:
            mw.shutdown()
    
    def test_sqlite_executemany(self):
        """Test SQLite executemany tracking"""
        mw.initialize()
        
        try:
            mw.set_config({'track_sql': 1})
            mw.wrap_sqlite3()
            
            conn = sqlite3.connect(':memory:')
            cursor = conn.cursor()
            
            cursor.execute('CREATE TABLE users (id INTEGER, name TEXT)')
            
            initial_count = mw.mw_get_event_count()
            
            # Execute many
            cursor.executemany('INSERT INTO users VALUES (?, ?)', [
                (1, 'Alice'),
                (2, 'Bob'),
                (3, 'Charlie'),
            ])
            
            final_count = mw.mw_get_event_count()
            
            assert final_count > initial_count, "executemany should be tracked"
            
            # Verify data
            cursor.execute('SELECT COUNT(*) FROM users')
            count = cursor.fetchone()[0]
            assert count == 3, "All rows should be inserted"
            
            conn.close()
        
        finally:
            mw.shutdown()
    
    def test_sql_parameter_capture(self):
        """Test that SQL parameters are captured"""
        mw.initialize()
        
        try:
            mw.set_config({'track_sql': 1})
            
            # Emit SQL event with parameters
            mw.emit_sql_event(
                db_type='sqlite',
                query='SELECT * FROM users WHERE id = ? AND name = ?',
                params={'values': (42, 'Alice')},
                call_file='test.py',
                call_line=50,
                execution_time_us=100
            )
            
            count = mw.mw_get_event_count()
            assert count > 0, "SQL event should be emitted"
        
        finally:
            mw.shutdown()
    
    def test_sql_call_site_capture(self):
        """Test that call site information is captured"""
        mw.initialize()
        
        try:
            mw.set_config({'track_sql': 1})
            
            # Emit with specific call site
            mw.emit_sql_event(
                db_type='sqlite',
                query='SELECT 1',
                params=None,
                call_file='my_module.py',
                call_line=123,
                execution_time_us=50
            )
            
            count = mw.mw_get_event_count()
            assert count > 0, "Event should be tracked"
        
        finally:
            mw.shutdown()
    
    def test_sql_thread_tracking(self):
        """Test SQL tracking in multiple threads"""
        mw.initialize()
        
        try:
            mw.set_config({'track_sql': 1})
            mw.wrap_sqlite3()
            
            initial_count = mw.mw_get_event_count()
            query_count = 0
            lock = threading.Lock()
            
            def run_queries():
                nonlocal query_count
                conn = sqlite3.connect(':memory:')
                cursor = conn.cursor()
                cursor.execute('CREATE TABLE t (id INTEGER)')
                
                for i in range(5):
                    cursor.execute('INSERT INTO t VALUES (?)', (i,))
                
                with lock:
                    query_count += 1
                
                conn.close()
            
            threads = [threading.Thread(target=run_queries) for _ in range(3)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            
            final_count = mw.mw_get_event_count()
            
            assert query_count == 3, "All threads should complete"
            assert final_count > initial_count, "SQL from all threads should be tracked"
        
        finally:
            mw.shutdown()
    
    def test_sql_timing_capture(self):
        """Test that execution time is captured"""
        mw.initialize()
        
        try:
            mw.set_config({'track_sql': 1})
            
            # Emit with timing information
            mw.emit_sql_event(
                db_type='sqlite',
                query='SELECT 1',
                params=None,
                call_file='test.py',
                call_line=100,
                execution_time_us=1500  # 1.5ms
            )
            
            count = mw.mw_get_event_count()
            assert count > 0, "Event with timing should be tracked"
        
        finally:
            mw.shutdown()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
