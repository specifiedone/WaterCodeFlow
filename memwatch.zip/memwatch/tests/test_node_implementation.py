"""Real functionality tests for Node.js MemWatch adapter"""

import pytest
import subprocess
import os
import tempfile
import json


class TestNodeJSRealImplementation:
    """Real functionality tests for Node.js memory tracking"""
    
    def test_nodejs_basic_execution(self):
        """Test: Basic Node.js script executes"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('console.log("Hello from Node.js");\nprocess.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0, result.stderr.decode()
        finally:
            os.unlink(script)
    
    def test_nodejs_with_memwatch_enabled(self):
        """Test: Node.js with --memwatch memory tracking"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('''
let arr = [];
for (let i = 0; i < 100; i++) {
    arr.push(new Array(1000).fill(Math.random()));
}
console.log("Allocated memory");
process.exit(0);
''')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0, result.stderr.decode()
        finally:
            os.unlink(script)
    
    def test_nodejs_with_debug_output(self):
        """Test: Node.js --memwatch-debug shows tracking info"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('console.log("Test"); process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch',
                 '--memwatch-debug',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
            output = result.stderr.decode('utf-8', errors='ignore')
            # Should show MemWatch initialization
            assert 'Node.js' in output or 'MemWatch' in output or result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_nodejs_track_file_scoping(self):
        """Test: --track-file flag limits tracking to specific file"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch',
                 f'--track-file={os.path.basename(script)}',
                 '--memwatch-debug',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_nodejs_track_module_scoping(self):
        """Test: --track-module flag limits tracking to specific module"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch',
                 '--track-module=app',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_nodejs_specific_variables(self):
        """Test: --memwatch-vars tracks specific variables"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('''
let sum = 0;
let data = [1, 2, 3];
for (let i = 0; i < 100; i++) {
    sum += i;
}
console.log(sum);
process.exit(0);
''')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch',
                 '--memwatch-vars=sum,data',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_nodejs_combined_flags(self):
        """Test: Multiple memwatch flags work together"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('let x = 1; process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch',
                 '--track-file=test.js',
                 '--track-module=app',
                 '--memwatch-debug',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_nodejs_missing_script(self):
        """Test: Error on missing script"""
        result = subprocess.run(
            ['python', 'cli/memwatch_cli.py',
             '--language=node',
             '--memwatch',
             '/nonexistent/script.js'],
            capture_output=True,
            timeout=5,
            cwd='/workspaces/WaterCodeFlow/memwatch'
        )
        assert result.returncode == 1
        assert b'not found' in result.stderr.lower()
    
    def test_nodejs_adapter_loaded(self):
        """Test: Node.js adapter loads correctly"""
        result = subprocess.run(
            ['python', '-c', 
             'from adapters.memwatch_adapter_node import initialize; print("OK")'],
            capture_output=True,
            timeout=5,
            cwd='/workspaces/WaterCodeFlow/memwatch'
        )
        assert result.returncode == 0
        assert b'OK' in result.stdout
    
    def test_nodejs_memory_growth_detection(self):
        """Test: Memory growth is tracked during execution"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('''
const before = process.memoryUsage().heapUsed;
const arrays = [];
for (let i = 0; i < 50; i++) {
    arrays.push(new Array(5000).fill(i));
}
const after = process.memoryUsage().heapUsed;
const growth = (after - before) / 1024 / 1024;
console.error('Memory growth: ' + growth.toFixed(2) + 'MB');
process.exit(0);
''')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 '--memwatch',
                 '--memwatch-debug',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
            output = result.stderr.decode('utf-8', errors='ignore')
            # Should show memory growth detection
            assert 'Memory' in output or 'MemWatch' in output or result.returncode == 0
        finally:
            os.unlink(script)
    
    def test_nodejs_without_memwatch_no_overhead(self):
        """Test: Without --memwatch flag, script runs normally"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write('console.log("Fast"); process.exit(0);')
            script = f.name
        
        try:
            result = subprocess.run(
                ['python', 'cli/memwatch_cli.py',
                 '--language=node',
                 script],
                capture_output=True,
                timeout=5,
                cwd='/workspaces/WaterCodeFlow/memwatch'
            )
            assert result.returncode == 0
            assert b'Fast' in result.stdout
        finally:
            os.unlink(script)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
