"""
Real Functionality Tests for Unified MemWatch CLI

Tests verify:
1. Language routing works correctly
2. Track-file flag limits tracking scope
3. Track-module flag limits tracking scope  
4. All memory tracking flags work
5. All SQL tracking flags work
6. All language adapters load correctly
"""

import subprocess
import sys
import os
import pytest
import tempfile
import json

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
MEMWATCH_DIR = os.path.dirname(TESTS_DIR)
CLI = os.path.join(MEMWATCH_DIR, 'cli', 'memwatch_cli.py')
TEST_APP = os.path.join(TESTS_DIR, 'test_app.py')


class TestUnifiedCLI:
    """Test the unified multi-language CLI"""
    
    def run_cli(self, *args, timeout=10):
        """Helper to run CLI with args"""
        cmd = [sys.executable, CLI] + list(args)
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result
    
    # ========================================================================
    # Python Language Tests
    # ========================================================================
    
    def test_python_basic_execution(self):
        """Test basic Python script execution"""
        result = self.run_cli('--language=python', TEST_APP)
        assert result.returncode == 0, f"Expected exit 0, got {result.returncode}"
        assert 'Starting test application' in result.stdout
        assert 'Done!' in result.stdout
    
    def test_python_with_memwatch_flag(self):
        """Test Python with --memwatch flag"""
        result = self.run_cli('--language=python', '--memwatch', TEST_APP)
        assert result.returncode == 0
        assert 'Starting test application' in result.stdout
        assert 'Done!' in result.stdout
    
    def test_python_with_sql_tracking(self):
        """Test Python with SQL tracking"""
        result = self.run_cli('--language=python', '--memwatch-sql', TEST_APP)
        assert result.returncode == 0
        assert 'Starting test application' in result.stdout
    
    def test_python_with_debug_output(self):
        """Test Python with debug flag"""
        result = self.run_cli('--language=python', '--memwatch-debug', TEST_APP)
        assert result.returncode == 0
        assert '[Python Adapter] Initialized' in result.stderr or '[Python Adapter] Initialized' in result.stdout
    
    def test_python_track_file_scope(self):
        """Test track-file flag to limit tracking scope"""
        result = self.run_cli(
            '--language=python',
            '--memwatch',
            '--track-file=test_app.py',
            '--memwatch-debug',
            TEST_APP
        )
        assert result.returncode == 0
        # Should show track file in config
        assert 'test_app.py' in result.stderr or 'test_app.py' in result.stdout
    
    def test_python_track_module_scope(self):
        """Test track-module flag to limit tracking scope"""
        result = self.run_cli(
            '--language=python',
            '--memwatch',
            '--track-module=test_app',
            '--memwatch-debug',
            TEST_APP
        )
        assert result.returncode == 0
        # Should show track module in config
        assert 'test_app' in result.stderr or 'test_app' in result.stdout
    
    def test_python_specific_variables(self):
        """Test --memwatch-vars to track specific variables"""
        result = self.run_cli(
            '--language=python',
            '--memwatch',
            '--memwatch-vars=result,data,count',
            TEST_APP
        )
        assert result.returncode == 0
        assert 'Done!' in result.stdout
    
    def test_python_locals_only(self):
        """Test --memwatch-locals flag"""
        result = self.run_cli(
            '--language=python',
            '--memwatch-locals',
            TEST_APP
        )
        assert result.returncode == 0
        assert 'Done!' in result.stdout
    
    def test_python_globals_only(self):
        """Test --memwatch-globals flag"""
        result = self.run_cli(
            '--language=python',
            '--memwatch-globals',
            TEST_APP
        )
        assert result.returncode == 0
        assert 'Done!' in result.stdout
    
    def test_python_track_all(self):
        """Test --memwatch-all flag (comprehensive tracking)"""
        result = self.run_cli(
            '--language=python',
            '--memwatch-all',
            TEST_APP
        )
        assert result.returncode == 0
        assert 'Done!' in result.stdout
    
    def test_python_with_threads_flag(self):
        """Test --memwatch-threads flag"""
        result = self.run_cli(
            '--language=python',
            '--memwatch',
            '--memwatch-threads',
            TEST_APP
        )
        assert result.returncode == 0
        assert 'Done!' in result.stdout
    
    def test_python_combined_flags(self):
        """Test combining multiple tracking flags"""
        result = self.run_cli(
            '--language=python',
            '--memwatch',
            '--memwatch-sql',
            '--memwatch-threads',
            '--track-file=test_app.py',
            '--memwatch-debug',
            TEST_APP
        )
        assert result.returncode == 0
        assert 'Done!' in result.stdout
    
    # ========================================================================
    # Multi-Language Adapter Tests
    # ========================================================================
    
    def test_node_adapter_loads(self):
        """Test Node.js adapter loads correctly"""
        result = self.run_cli(
            '--language=node',
            '--memwatch-debug',
            TEST_APP
        )
        # Should fail on script execution (Python file), but adapter should load
        assert '[Node.js Adapter] Initialized' in result.stderr or '[Node.js Adapter] Initialized' in result.stdout
    
    def test_go_adapter_loads(self):
        """Test Go adapter loads correctly"""
        result = self.run_cli(
            '--language=go',
            '--memwatch-debug',
            TEST_APP
        )
        # Should fail on script execution, but adapter should load
        assert '[Go Adapter] Initialized' in result.stderr or '[Go Adapter] Initialized' in result.stdout
    
    def test_rust_adapter_loads(self):
        """Test Rust adapter loads correctly"""
        result = self.run_cli(
            '--language=rust',
            '--memwatch-debug',
            TEST_APP
        )
        assert '[Rust Adapter] Initialized' in result.stderr or '[Rust Adapter] Initialized' in result.stdout
    
    def test_cpp_adapter_loads(self):
        """Test C++ adapter loads correctly"""
        result = self.run_cli(
            '--language=cpp',
            '--memwatch-debug',
            TEST_APP
        )
        assert '[C++ Adapter] Initialized' in result.stderr or '[C++ Adapter] Initialized' in result.stdout
    
    def test_csharp_adapter_loads(self):
        """Test C# adapter loads correctly"""
        result = self.run_cli(
            '--language=csharp',
            '--memwatch-debug',
            TEST_APP
        )
        assert '[C# Adapter] Initialized' in result.stderr or '[C# Adapter] Initialized' in result.stdout
    
    def test_java_adapter_loads(self):
        """Test Java adapter loads correctly"""
        result = self.run_cli(
            '--language=java',
            '--memwatch-debug',
            TEST_APP
        )
        assert '[Java Adapter] Initialized' in result.stderr or '[Java Adapter] Initialized' in result.stdout
    
    def test_ruby_adapter_loads(self):
        """Test Ruby adapter loads correctly"""
        result = self.run_cli(
            '--language=ruby',
            '--memwatch-debug',
            TEST_APP
        )
        assert '[Ruby Adapter] Initialized' in result.stderr or '[Ruby Adapter] Initialized' in result.stdout
    
    def test_php_adapter_loads(self):
        """Test PHP adapter loads correctly"""
        result = self.run_cli(
            '--language=php',
            '--memwatch-debug',
            TEST_APP
        )
        assert '[PHP Adapter] Initialized' in result.stderr or '[PHP Adapter] Initialized' in result.stdout
    
    def test_kotlin_adapter_loads(self):
        """Test Kotlin adapter loads correctly"""
        result = self.run_cli(
            '--language=kotlin',
            '--memwatch-debug',
            TEST_APP
        )
        assert '[Kotlin Adapter] Initialized' in result.stderr or '[Kotlin Adapter] Initialized' in result.stdout
    
    # ========================================================================
    # Configuration Tests
    # ========================================================================
    
    def test_store_bytes_configuration(self):
        """Test --memwatch-store-bytes flag"""
        result = self.run_cli(
            '--language=python',
            '--memwatch',
            '--memwatch-store-bytes=512',
            TEST_APP
        )
        assert result.returncode == 0
        assert 'Done!' in result.stdout
    
    def test_output_file_configuration(self):
        """Test --memwatch-output flag"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            output_file = f.name
        
        try:
            result = self.run_cli(
                '--language=python',
                '--memwatch',
                f'--memwatch-output={output_file}',
                TEST_APP
            )
            assert result.returncode == 0
            # File should be created (adapter should handle it)
        finally:
            if os.path.exists(output_file):
                os.unlink(output_file)
    
    # ========================================================================
    # Error Handling Tests
    # ========================================================================
    
    def test_missing_script(self):
        """Test error when script doesn't exist"""
        result = self.run_cli(
            '--language=python',
            'nonexistent_script.py'
        )
        assert result.returncode != 0
        assert 'not found' in result.stderr.lower()
    
    def test_invalid_language(self):
        """Test error on invalid language"""
        result = self.run_cli(
            '--language=invalid_lang',
            TEST_APP
        )
        assert result.returncode != 0
    
    def test_missing_language(self):
        """Test error when --language not specified"""
        result = self.run_cli(TEST_APP)
        assert result.returncode != 0


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--timeout=10'])
