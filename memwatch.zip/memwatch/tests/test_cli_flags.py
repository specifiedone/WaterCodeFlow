"""
MemWatch Integration Tests - CLI Flags

Real execution tests for command-line flag parsing and enforcement.
"""

import sys
import os
import pytest
import subprocess
import tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestCliFlags:
    """Test CLI flag parsing and enforcement"""
    
    def test_python_cli_help(self):
        """Test Python CLI help"""
        cli_path = os.path.join(os.path.dirname(__file__), '..', 'cli', 'python_cli.py')
        result = subprocess.run([sys.executable, cli_path, '-h'],
                                capture_output=True, text=True)
        
        # Should show usage
        assert 'usage:' in result.stdout.lower() or 'usage:' in result.stderr.lower(), \
            "Help should be displayed"
    
    def test_python_cli_script_missing(self):
        """Test Python CLI with missing script"""
        cli_path = os.path.join(os.path.dirname(__file__), '..', 'cli', 'python_cli.py')
        result = subprocess.run([sys.executable, cli_path, 'nonexistent.py'],
                                capture_output=True, text=True)
        
        # Should fail
        assert result.returncode != 0, "Should fail with missing script"
        assert 'not found' in result.stderr.lower(), "Should indicate script not found"
    
    def test_python_cli_execute_simple_script(self):
        """Test executing a simple Python script"""
        cli_path = os.path.join(os.path.dirname(__file__), '..', 'cli', 'python_cli.py')
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write('print("Hello from MemWatch")\n')
            f.write('x = 42\n')
            f.write('print(f"x = {x}")\n')
            script_path = f.name
        
        try:
            result = subprocess.run([sys.executable, cli_path, script_path],
                                    capture_output=True, text=True, timeout=5)
            
            assert result.returncode == 0, f"Script should execute successfully: {result.stderr}"
            assert 'Hello from MemWatch' in result.stdout, "Script output should appear"
            assert 'x = 42' in result.stdout, "Variable output should appear"
        
        finally:
            os.unlink(script_path)
    
    def test_python_cli_memwatch_flag(self):
        """Test --memwatch flag"""
        cli_path = os.path.join(os.path.dirname(__file__), '..', 'cli', 'python_cli.py')
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write('x = [1, 2, 3]\n')
            f.write('print("Script executed")\n')
            script_path = f.name
        
        try:
            result = subprocess.run(
                [sys.executable, cli_path, '--memwatch', script_path],
                capture_output=True, text=True, timeout=5
            )
            
            assert result.returncode == 0, f"Should execute with --memwatch: {result.stderr}"
            assert 'Script executed' in result.stdout, "Script should run"
        
        finally:
            os.unlink(script_path)
    
    def test_python_cli_sql_flag(self):
        """Test --memwatch-sql flag"""
        cli_path = os.path.join(os.path.dirname(__file__), '..', 'cli', 'python_cli.py')
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write('import sqlite3\n')
            f.write('conn = sqlite3.connect(":memory:")\n')
            f.write('cursor = conn.cursor()\n')
            f.write('cursor.execute("CREATE TABLE test (id INTEGER)")\n')
            f.write('cursor.execute("INSERT INTO test VALUES (1)")\n')
            f.write('print("Database operations completed")\n')
            f.write('conn.close()\n')
            script_path = f.name
        
        try:
            result = subprocess.run(
                [sys.executable, cli_path, '--memwatch-sql', script_path],
                capture_output=True, text=True, timeout=5
            )
            
            assert result.returncode == 0, f"Should execute with --memwatch-sql: {result.stderr}"
            assert 'Database operations completed' in result.stdout, "Script should run"
        
        finally:
            os.unlink(script_path)
    
    def test_python_cli_debug_flag(self):
        """Test --memwatch-debug flag"""
        cli_path = os.path.join(os.path.dirname(__file__), '..', 'cli', 'python_cli.py')
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write('print("Debug test")\n')
            script_path = f.name
        
        try:
            result = subprocess.run(
                [sys.executable, cli_path, '--memwatch-debug', script_path],
                capture_output=True, text=True, timeout=5
            )
            
            # Should execute, possibly with debug output
            assert 'Debug test' in result.stdout, "Script should run"
        
        finally:
            os.unlink(script_path)
    
    def test_python_cli_output_flag(self):
        """Test --memwatch-output flag"""
        cli_path = os.path.join(os.path.dirname(__file__), '..', 'cli', 'python_cli.py')
        
        with tempfile.TemporaryDirectory() as tmpdir:
            script_path = os.path.join(tmpdir, 'test.py')
            output_path = os.path.join(tmpdir, 'output.log')
            
            with open(script_path, 'w') as f:
                f.write('print("Output test")\n')
            
            result = subprocess.run(
                [sys.executable, cli_path, '--memwatch-sql',
                 f'--memwatch-output={output_path}', script_path],
                capture_output=True, text=True, timeout=5
            )
            
            assert result.returncode == 0, f"Should execute with output flag: {result.stderr}"
            assert 'Output test' in result.stdout, "Script should run"
    
    def test_python_cli_store_bytes_flag(self):
        """Test --memwatch-store-bytes flag"""
        cli_path = os.path.join(os.path.dirname(__file__), '..', 'cli', 'python_cli.py')
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write('data = "x" * 10000\n')
            f.write('print("Data created")\n')
            script_path = f.name
        
        try:
            result = subprocess.run(
                [sys.executable, cli_path, '--memwatch-store-bytes=1024', script_path],
                capture_output=True, text=True, timeout=5
            )
            
            assert result.returncode == 0, f"Should execute with store-bytes flag: {result.stderr}"
            assert 'Data created' in result.stdout, "Script should run"
        
        finally:
            os.unlink(script_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
