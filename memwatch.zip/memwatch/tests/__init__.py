"""MemWatch tests __init__"""
