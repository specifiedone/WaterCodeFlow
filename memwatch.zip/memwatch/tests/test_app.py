#!/usr/bin/env python3
"""
Sample application for testing MemWatch tracking
"""

import time
import sqlite3

def fibonacci(n):
    """CPU-bound computation"""
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

def database_operations():
    """I/O-bound operations"""
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create table
    cursor.execute('CREATE TABLE users (id INTEGER, name TEXT, age INTEGER)')
    
    # Insert data
    for i in range(100):
        cursor.execute('INSERT INTO users VALUES (?, ?, ?)', (i, f'User{i}', 20 + (i % 50)))
    
    # Query data
    cursor.execute('SELECT COUNT(*) FROM users')
    count = cursor.fetchone()[0]
    
    conn.close()
    return count

def main():
    """Main application"""
    print("Starting test application...")
    
    # CPU-bound
    print("Computing fibonacci(20)...")
    result = fibonacci(20)
    print(f"Result: {result}")
    
    # I/O with database
    print("Performing database operations...")
    user_count = database_operations()
    print(f"Created {user_count} users")
    
    # Memory allocation
    print("Allocating memory...")
    data = [i * 2 for i in range(10000)]
    print(f"Allocated list with {len(data)} elements")
    
    print("Done!")

if __name__ == '__main__':
    main()
