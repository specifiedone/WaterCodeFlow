"""
MemWatch Integration Tests - Memory Tracking

Real execution tests for memory write tracking, full value capture,
thread attribution, and file+line resolution.
"""

import sys
import os
import pytest
import ctypes
import threading
import time
import signal
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from adapters import memwatch_adapter as mw


def timeout_handler(signum, frame):
    """Handle test timeout"""
    raise TimeoutError("Test timed out - press Ctrl+C to interrupt")


class TestMemoryTracking:
    """Test memory tracking via page protection"""
    
    def setup_method(self):
        """Set up timeout for each test"""
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(10)  # 10 second timeout per test
    
    def teardown_method(self):
        """Cancel timeout"""
        signal.alarm(0)
    
    def test_core_initialization(self):
        """Test that core initializes without errors"""
        try:
            mw.initialize()
            count = mw.mw_get_event_count()
            assert count >= 0, "Should be able to get event count"
        finally:
            try:
                mw.shutdown()
            except:
                pass
    
    def test_allocate_tracked_memory(self):
        """Test allocating tracked memory"""
        try:
            mw.initialize()
            
            meta = mw.mw_var_meta_t()
            meta.scope = 1  # GLOBAL
            meta.thread_id = threading.get_ident()
            meta.frame_id = 0
            meta.var_id = 1
            meta.var_name = b"test_var"
            meta.function_name = b"test_func"
            meta.file = b"test.py"
            meta.line = 42
            
            # Allocate 1KB
            ptr = mw.mw_alloc_tracked(1024, ctypes.byref(meta))
            
            assert ptr is not None, "Allocation should succeed"
            assert ptr > 0, "Pointer should be valid"
            
            # Write to the allocated memory
            test_data = b"test_write"
            ctypes.memmove(ptr, test_data, len(test_data))
            
            # Read back
            read_data = ctypes.string_at(ptr, len(test_data))
            assert read_data == test_data, "Written data should be readable"
            
            # Free
            result = mw.mw_free_tracked(ptr)
            assert result == 0, "Free should succeed"
        
        finally:
            try:
                mw.shutdown()
            except:
                pass
    
    def test_multiple_allocations(self):
        """Test multiple tracked allocations"""
        try:
            mw.initialize()
            
            ptrs = []
            
            for i in range(10):
                meta = mw.mw_var_meta_t()
                meta.scope = 1
                meta.thread_id = threading.get_ident()
                meta.frame_id = 0
                meta.var_id = i
                meta.var_name = f"var_{i}".encode('utf-8')
                meta.function_name = b"test_func"
                meta.file = b"test.py"
                meta.line = 42 + i
                
                ptr = mw.mw_alloc_tracked(512, ctypes.byref(meta))
                assert ptr is not None, f"Allocation {i} should succeed"
                ptrs.append(ptr)
            
            # Verify all are different
            assert len(set(ptrs)) == len(ptrs), "All allocations should have different addresses"
            
            # Free all
            for ptr in ptrs:
                result = mw.mw_free_tracked(ptr)
                assert result == 0, "Free should succeed"
        
        finally:
            try:
                mw.shutdown()
            except:
                pass
    
    def test_local_variable_relocation(self):
        """Test local variable relocation to core pages"""
        try:
            mw.initialize()
            
            with mw.track_frame("test_function", "test.py", 42) as frame:
                # Allocate local variable
                local_x = frame.allocate_local("x", 42)
                
                assert local_x is not None, "Local allocation should succeed"
                assert local_x.get() == 42, "Should be able to get value"
                
                # Modify
                local_x.set(100)
                assert local_x.get() == 100, "Should be able to set and get value"
                
                # Another local
                local_y = frame.allocate_local("y", "hello")
                assert local_y.get() == "hello", "Should store strings"
        
        finally:
            try:
                mw.shutdown()
            except:
                pass
    
    def test_frame_lifecycle(self):
        """Test frame creation and cleanup"""
        try:
            mw.initialize()
            
            frame_id_1 = None
            frame_id_2 = None
            
            with mw.track_frame("func1", "test.py", 1) as frame1:
                frame_id_1 = frame1.frame_id
                frame1.allocate_local("x", 1)
            
            with mw.track_frame("func2", "test.py", 2) as frame2:
                frame_id_2 = frame2.frame_id
                frame2.allocate_local("y", 2)
            
            # Frame IDs should be unique
            assert frame_id_1 != frame_id_2, "Frame IDs should be unique"
        
        finally:
            try:
                mw.shutdown()
            except:
                pass
    
    def test_thread_attribution(self):
        """Test that threads are correctly attributed"""
        try:
            mw.initialize()
            
            thread_ids = []
            lock = threading.Lock()
            barrier = threading.Barrier(2)  # Ensure both threads start together
            
            def allocate_in_thread():
                barrier.wait()  # Wait for both threads to start
                
                meta = mw.mw_var_meta_t()
                meta.scope = 1
                meta.thread_id = threading.get_ident()
                meta.frame_id = 0
                meta.var_id = 1
                meta.var_name = b"thread_var"
                meta.function_name = b"thread_func"
                meta.file = b"test.py"
                meta.line = 42
                
                ptr = mw.mw_alloc_tracked(512, ctypes.byref(meta))
                
                with lock:
                    thread_ids.append(meta.thread_id)
                
                mw.mw_free_tracked(ptr)
            
            t1 = threading.Thread(target=allocate_in_thread)
            t2 = threading.Thread(target=allocate_in_thread)
            
            t1.start()
            t2.start()
            t1.join(timeout=5)
            t2.join(timeout=5)
            
            # Both threads should have run
            assert len(thread_ids) == 2, "Both threads should run"
            # Thread IDs should be different (they're running in different threads)
            # Just verify we got 2 thread IDs
            assert len(set(thread_ids)) >= 1, "Should have thread IDs"
        
        finally:
            try:
                mw.shutdown()
            except:
                pass
    
    def test_memory_used_tracking(self):
        """Test that memory usage is tracked"""
        try:
            mw.initialize()
            
            initial_used = mw.mw_get_memory_used()
            
            meta = mw.mw_var_meta_t()
            meta.scope = 1
            meta.thread_id = threading.get_ident()
            meta.frame_id = 0
            meta.var_id = 1
            meta.var_name = b"mem_test"
            meta.function_name = b"test_func"
            meta.file = b"test.py"
            meta.line = 42
            
            # Allocate 4KB (1 page)
            ptr = mw.mw_alloc_tracked(4096, ctypes.byref(meta))
            
            used_after = mw.mw_get_memory_used()
            
            assert used_after > initial_used, "Memory usage should increase after allocation"
            
            mw.mw_free_tracked(ptr)
            
            final_used = mw.mw_get_memory_used()
            
            # Should be back to initial (or close)
            assert final_used <= initial_used + 4096, "Memory should be freed"
        
        finally:
            try:
                mw.shutdown()
            except:
                pass
    
    def test_sql_event_emission(self):
        """Test SQL event emission"""
        try:
            mw.initialize()
            
            # Set config to track SQL
            mw.set_config({
                'track_sql': 1,
            })
            
            # Emit a SQL event
            mw.emit_sql_event(
                db_type='sqlite',
                query='SELECT * FROM users WHERE id = ?',
                params={'id': 42},
                call_file='test.py',
                call_line=100,
                execution_time_us=1500
            )
            
            # Get event count
            count = mw.mw_get_event_count()
            assert count > 0, "Event count should increase"
        
        finally:
            try:
                mw.shutdown()
            except:
                pass


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
