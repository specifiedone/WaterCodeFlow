#!/usr/bin/env python3
"""
Test runner for MemWatch with proper interrupt handling
"""

import sys
import os
import subprocess
import signal

def run_tests():
    """Run pytest with proper interrupt handling"""
    env = os.environ.copy()
    env['PYTHONUNBUFFERED'] = '1'
    
    cmd = [
        sys.executable, '-m', 'pytest',
        'tests/', '-v', '--tb=short',
        '-x',  # stop on first failure
        '--timeout=30'  # 30s per test
    ]
    
    try:
        result = subprocess.run(cmd, env=env)
        return result.returncode
    except KeyboardInterrupt:
        print("\n\nTests interrupted by user (Ctrl+C)")
        return 130

if __name__ == '__main__':
    sys.exit(run_tests())
